DARK LUXURY Launcher v1.1

What's updated:
- Bottom Settings button removed.
- Long press on the home screen opens the launcher menu.
- Time and date are draggable and their positions are saved.
- Essential apps panel added to the home screen.
- Custom luxury icon pack assets included from the provided ZIP.
- All Apps and folders remain available.
- Launcher Settings page is now opened from the long-press menu.

Build:
1. Open this project in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK.

Notes:
- Android system permissions are requested only through official Android screens.
- The launcher can be set as the default Home app from the menu or the settings page.
