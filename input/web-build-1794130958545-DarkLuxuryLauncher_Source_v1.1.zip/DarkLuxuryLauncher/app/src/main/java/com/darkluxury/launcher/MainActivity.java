package com.darkluxury.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.app.role.RoleManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int GOLD = Color.rgb(220, 184, 105);
    private static final int MUTED = Color.rgb(154, 150, 145);
    private static final int BG = Color.rgb(8, 9, 11);
    private static final int PANEL = Color.rgb(23, 24, 27);
    private static final int PANEL_2 = Color.rgb(18, 19, 22);
    private static final int PICK_WALLPAPER = 210;
    private static final String PREFS = "dark_luxury_prefs";

    private FrameLayout root;
    private LinearLayout surface;
    private TextView clock;
    private TextView dateText;
    private boolean inSubPage = false;
    private float downY;

    private final Handler handler = new Handler();
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 1000);
        }
    };

    private final Map<String, String> iconMap = new HashMap<>();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        initIconMap();
        buildHome();
        handler.post(tick);
        if (!prefs().getBoolean("welcomed", false)) {
            prefs().edit().putBoolean("welcomed", true).apply();
            new Handler().postDelayed(this::showWelcome, 400);
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(tick);
        super.onDestroy();
    }

    private android.content.SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable panelBg(int color, int radius, boolean border) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (border) d.setStroke(dp(1), Color.rgb(102, 82, 40));
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void initIconMap() {
        iconMap.put("phone", "solid_phone.png");
        iconMap.put("dialer", "solid_phone.png");
        iconMap.put("message", "solid_comments.png");
        iconMap.put("messages", "solid_comments.png");
        iconMap.put("sms", "solid_comments.png");
        iconMap.put("camera", "solid_camera.png");
        iconMap.put("chrome", "brands_chrome.png");
        iconMap.put("browser", "solid_globe.png");
        iconMap.put("internet", "solid_globe.png");
        iconMap.put("play store", "brands_google-play.png");
        iconMap.put("telegram", "brands_telegram.png");
        iconMap.put("whatsapp", "brands_whatsapp.png");
        iconMap.put("youtube", "brands_youtube.png");
        iconMap.put("gallery", "solid_images.png");
        iconMap.put("photos", "solid_images.png");
        iconMap.put("instagram", "brands_instagram.png");
        iconMap.put("tiktok", "brands_tiktok.png");
        iconMap.put("files", "solid_folder-open.png");
        iconMap.put("file", "solid_file.png");
        iconMap.put("settings", "solid_gear.png");
        iconMap.put("clock", "solid_clock.png");
        iconMap.put("calendar", "solid_calendar-days.png");
        iconMap.put("music", "solid_music.png");
        iconMap.put("video", "solid_video.png");
        iconMap.put("calculator", "solid_calculator.png");
        iconMap.put("notes", "solid_note-sticky.png");
        iconMap.put("drive", "brands_google-drive.png");
        iconMap.put("game", "solid_gamepad.png");
        iconMap.put("polywar", "solid_crosshairs.png");
        iconMap.put("pubg", "solid_crosshairs.png");
        iconMap.put("default", "Generic_App.png");
    }

    private void buildHome() {
        inSubPage = false;
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);

        surface = column();
        surface.setPadding(dp(18), dp(20), dp(18), dp(18));
        root.addView(surface, new FrameLayout.LayoutParams(-1, -1));

        surface.addView(createBrandHeader("Luxury dark launcher"));

        FrameLayout hero = new FrameLayout(this);
        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        surface.addView(hero, heroParams);

        clock = text("", 62, Color.WHITE, false);
        clock.setLetterSpacing(-0.02f);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        cp.topMargin = dp(46);
        hero.addView(clock, cp);
        makeDraggable(clock, "clock");

        dateText = text("", 12, MUTED, false);
        dateText.setAllCaps(true);
        FrameLayout.LayoutParams dp2 = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        dp2.topMargin = dp(166);
        hero.addView(dateText, dp2);
        makeDraggable(dateText, "date");

        LinearLayout quickPanel = column();
        quickPanel.setBackground(panelBg(PANEL_2, 22, true));
        quickPanel.setPadding(dp(14), dp(14), dp(14), dp(14));
        FrameLayout.LayoutParams qp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        qp.bottomMargin = dp(112);
        hero.addView(quickPanel, qp);

        TextView quickTitle = text("ESSENTIAL APPS", 10, GOLD, true);
        quickTitle.setLetterSpacing(0.12f);
        quickPanel.addView(quickTitle);
        GridLayout homeApps = new GridLayout(this);
        homeApps.setColumnCount(4);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(10);
        quickPanel.addView(homeApps, hp);
        renderHomeApps(homeApps);

        TextView hint = text("SWIPE UP  ·  ALL APPS", 10, MUTED, true);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(8), 0, dp(16));
        surface.addView(hint);

        LinearLayout dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(8), dp(12), dp(8), dp(12));
        dock.setBackground(panelBg(PANEL, 24, true));
        surface.addView(dock, new LinearLayout.LayoutParams(-1, -2));
        addDock(dock, "APPS", this::showDrawer);
        addDock(dock, "FOLDERS", this::showFolders);

        root.setOnLongClickListener(v -> {
            showLongPressMenu();
            return true;
        });
        root.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downY = e.getY();
            } else if (e.getAction() == MotionEvent.ACTION_UP) {
                if (downY - e.getY() > dp(58)) showDrawer();
            }
            return false;
        });

        updateClock();
    }

    private LinearLayout createBrandHeader(String subtitle) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView logo = text("DL", 14, GOLD, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(panelBg(PANEL, 14, true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
        header.addView(logo, lp);

        LinearLayout texts = column();
        texts.setPadding(dp(12), 0, 0, 0);
        TextView title = text("DARK LUXURY", 15, GOLD, true);
        title.setLetterSpacing(0.22f);
        texts.addView(title);
        TextView sub = text(subtitle, 10, MUTED, false);
        sub.setPadding(0, dp(2), 0, 0);
        texts.addView(sub);
        header.addView(texts, new LinearLayout.LayoutParams(-2, -2));

        return header;
    }

    private void addDock(LinearLayout parent, String label, Runnable click) {
        TextView b = text(label, 11, GOLD, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        b.setOnClickListener(v -> click.run());
        parent.addView(b, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    private void makeDraggable(View view, String key) {
        view.setTranslationX(prefs().getFloat(key + "_x", 0));
        view.setTranslationY(prefs().getFloat(key + "_y", 0));
        final float[] last = new float[2];
        view.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    last[0] = e.getRawX();
                    last[1] = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float nx = v.getTranslationX() + (e.getRawX() - last[0]);
                    float ny = v.getTranslationY() + (e.getRawY() - last[1]);
                    nx = Math.max(-dp(120), Math.min(dp(120), nx));
                    ny = Math.max(-dp(200), Math.min(dp(250), ny));
                    v.setTranslationX(nx);
                    v.setTranslationY(ny);
                    last[0] = e.getRawX();
                    last[1] = e.getRawY();
                    return true;
                case MotionEvent.ACTION_UP:
                    prefs().edit().putFloat(key + "_x", v.getTranslationX()).putFloat(key + "_y", v.getTranslationY()).apply();
                    return true;
            }
            return false;
        });
    }

    private void updateClock() {
        Date now = new Date();
        if (clock != null) clock.setText(new SimpleDateFormat("HH:mm", Locale.ENGLISH).format(now));
        if (dateText != null) dateText.setText(new SimpleDateFormat("EEEE  ·  dd MMMM yyyy", Locale.ENGLISH).format(now).toUpperCase(Locale.ENGLISH));
    }

    private void showLongPressMenu() {
        final String[] items = {
                "All Apps",
                "Smart Folders",
                "Launcher Settings",
                "Set Default Home",
                "Change Wallpaper",
                "Notification Access",
                "Usage Access"
        };
        new AlertDialog.Builder(this)
                .setTitle("DARK LUXURY MENU")
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0: showDrawer(); break;
                        case 1: showFolders(); break;
                        case 2: showSettings(); break;
                        case 3: requestHomeRole(); break;
                        case 4: pickWallpaper(); break;
                        case 5: openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS); break;
                        case 6: openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS); break;
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void newPage(String title, String subtitle) {
        inSubPage = true;
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        surface = column();
        surface.setPadding(dp(16), dp(18), dp(16), dp(12));
        root.addView(surface, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = text("‹", 24, GOLD, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(panelBg(PANEL, 14, true));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(42), dp(42));
        top.addView(back, bp);
        back.setOnClickListener(v -> buildHome());

        LinearLayout brandWrap = column();
        brandWrap.setPadding(dp(12), 0, 0, 0);
        TextView t = text(title, 15, GOLD, true);
        t.setLetterSpacing(0.18f);
        brandWrap.addView(t);
        TextView s = text(subtitle, 10, MUTED, false);
        s.setPadding(0, dp(2), 0, 0);
        brandWrap.addView(s);
        top.addView(brandWrap, new LinearLayout.LayoutParams(-2, -2));

        surface.addView(top);
    }

    private List<ResolveInfo> apps() {
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = getPackageManager().queryIntentActivities(i, 0);
        found.sort((a, b) -> a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        return found;
    }

    private Drawable customIconFor(ResolveInfo app) {
        String label = app.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
        String pkg = app.activityInfo.packageName.toLowerCase(Locale.ROOT);
        String file = null;
        for (Map.Entry<String, String> e : iconMap.entrySet()) {
            String key = e.getKey();
            if ("default".equals(key)) continue;
            if (label.contains(key) || pkg.contains(key.replace(" ", "")) || pkg.contains(key.replace(" ", "."))) {
                file = e.getValue();
                break;
            }
        }
        if (file == null) {
            int category = app.activityInfo.applicationInfo.category;
            if (category == ApplicationInfo.CATEGORY_GAME) file = "solid_gamepad.png";
            else file = iconMap.get("default");
        }
        try {
            InputStream is = getAssets().open("icons/" + file);
            BitmapDrawable d = new BitmapDrawable(getResources(), BitmapFactory.decodeStream(is));
            is.close();
            return d;
        } catch (Exception ignored) {
            try {
                return app.loadIcon(getPackageManager());
            } catch (Exception e) {
                return null;
            }
        }
    }

    private void showDrawer() {
        newPage("ALL APPS", "Luxury icon pack enabled");

        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search apps...");
        search.setHintTextColor(MUTED);
        search.setTextColor(Color.WHITE);
        search.setTextSize(15);
        search.setPadding(dp(15), dp(12), dp(15), dp(12));
        search.setBackground(panelBg(PANEL, 16, true));
        LinearLayout.LayoutParams sep = new LinearLayout.LayoutParams(-1, -2);
        sep.setMargins(0, dp(16), 0, dp(10));
        surface.addView(search, sep);

        ScrollView scroll = new ScrollView(this);
        surface.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setPadding(0, dp(8), 0, dp(22));
        scroll.addView(grid);

        List<ResolveInfo> all = apps();
        renderApps(grid, all);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String q = s.toString().toLowerCase(Locale.ROOT);
                List<ResolveInfo> filtered = new ArrayList<>();
                for (ResolveInfo r : all) {
                    String label = r.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
                    if (label.contains(q)) filtered.add(r);
                }
                renderApps(grid, filtered);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void renderApps(GridLayout grid, List<ResolveInfo> all) {
        grid.removeAllViews();
        int width = getResources().getDisplayMetrics().widthPixels - dp(32);
        int cell = width / 4;
        for (ResolveInfo app : all) {
            LinearLayout item = column();
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(4), dp(12), dp(4), dp(12));

            ImageView icon = new ImageView(this);
            Drawable d = customIconFor(app);
            if (d != null) icon.setImageDrawable(d);
            item.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

            TextView title = text(app.loadLabel(getPackageManager()).toString(), 10, Color.LTGRAY, false);
            title.setGravity(Gravity.CENTER);
            title.setMaxLines(2);
            title.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, dp(34));
            tp.topMargin = dp(7);
            item.addView(title, tp);

            grid.addView(item, new ViewGroup.LayoutParams(cell, dp(110)));
            item.setOnClickListener(v -> launchApp(app));
        }
    }

    private void renderHomeApps(GridLayout grid) {
        grid.removeAllViews();
        List<ResolveInfo> list = pickEssentialApps();
        int width = getResources().getDisplayMetrics().widthPixels - dp(64);
        int cell = width / 4;
        for (ResolveInfo app : list) {
            LinearLayout item = column();
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(4), dp(8), dp(4), dp(8));

            FrameLayout holder = new FrameLayout(this);
            holder.setBackground(panelBg(PANEL, 16, false));
            holder.setPadding(dp(10), dp(10), dp(10), dp(10));
            ImageView icon = new ImageView(this);
            Drawable d = customIconFor(app);
            if (d != null) icon.setImageDrawable(d);
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER);
            holder.addView(icon, ip);
            item.addView(holder, new LinearLayout.LayoutParams(dp(58), dp(58)));

            String labelText = app.loadLabel(getPackageManager()).toString();
            if (labelText.length() > 10) labelText = labelText.substring(0, 10);
            TextView title = text(labelText, 10, Color.WHITE, false);
            title.setGravity(Gravity.CENTER);
            title.setMaxLines(1);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
            tp.topMargin = dp(6);
            item.addView(title, tp);

            grid.addView(item, new ViewGroup.LayoutParams(cell, dp(92)));
            item.setOnClickListener(v -> launchApp(app));
            item.setOnLongClickListener(v -> {
                Toast.makeText(this, app.loadLabel(getPackageManager()).toString(), Toast.LENGTH_SHORT).show();
                return true;
            });
        }
    }

    private List<ResolveInfo> pickEssentialApps() {
        List<ResolveInfo> all = apps();
        List<String> keys = Arrays.asList("phone", "messages", "camera", "chrome", "play store", "telegram", "whatsapp", "youtube");
        List<ResolveInfo> picked = new ArrayList<>();
        Set<String> added = new HashSet<>();
        for (String key : keys) {
            for (ResolveInfo app : all) {
                String label = app.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
                String pkg = app.activityInfo.packageName.toLowerCase(Locale.ROOT);
                if (!added.contains(pkg) && (label.contains(key) || pkg.contains(key.replace(" ", "")) || pkg.contains(key.replace(" ", ".")))) {
                    picked.add(app);
                    added.add(pkg);
                    break;
                }
            }
        }
        for (ResolveInfo app : all) {
            String pkg = app.activityInfo.packageName;
            if (!added.contains(pkg)) {
                picked.add(app);
                added.add(pkg);
            }
            if (picked.size() >= 8) break;
        }
        if (picked.size() > 8) return picked.subList(0, 8);
        return picked;
    }

    private void launchApp(ResolveInfo app) {
        try {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            intent.setComponent(new ComponentName(app.activityInfo.packageName, app.activityInfo.name));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception ex) {
            Toast.makeText(this, "Unable to open this app", Toast.LENGTH_SHORT).show();
        }
    }

    private void showFolders() {
        newPage("SMART FOLDERS", "Grouped shortcuts");
        String[] names = {"GAMES", "GOOGLE", "SOCIAL", "TOOLS", "OTHER"};
        for (String n : names) {
            TextView t = folderButton(n);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.setMargins(0, dp(14), 0, 0);
            surface.addView(t, p);
        }
    }

    private TextView folderButton(String label) {
        TextView v = text("◈   " + label + "   ›", 14, GOLD, true);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(16), dp(15), dp(16), dp(15));
        v.setBackground(panelBg(PANEL, 16, true));
        v.setOnClickListener(x -> showFolder(label));
        return v;
    }

    private String groupFor(ResolveInfo r) {
        String pkg = r.activityInfo.packageName.toLowerCase(Locale.ROOT);
        String label = r.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
        if (r.activityInfo.applicationInfo.category == ApplicationInfo.CATEGORY_GAME || pkg.contains("game") || label.contains("game") || label.contains("polywar") || label.contains("pubg")) return "GAMES";
        if (pkg.startsWith("com.google") || label.contains("google") || label.contains("chrome") || label.contains("youtube") || label.contains("gmail")) return "GOOGLE";
        if (pkg.contains("instagram") || pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("facebook") || pkg.contains("tiktok") || pkg.contains("discord")) return "SOCIAL";
        if (label.contains("settings") || label.contains("file") || label.contains("clock") || label.contains("calculator") || label.contains("camera") || label.contains("gallery")) return "TOOLS";
        return "OTHER";
    }

    private void showFolder(String name) {
        newPage(name, "Folder view");
        ScrollView sv = new ScrollView(this);
        surface.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        GridLayout g = new GridLayout(this);
        g.setColumnCount(4);
        g.setPadding(0, dp(8), 0, dp(18));
        sv.addView(g);
        List<ResolveInfo> selected = new ArrayList<>();
        for (ResolveInfo r : apps()) if (groupFor(r).equals(name)) selected.add(r);
        renderApps(g, selected);
    }

    private void showSettings() {
        newPage("LAUNCHER SETTINGS", "Long press from home to open this menu");
        ScrollView sc = new ScrollView(this);
        surface.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout list = column();
        list.setPadding(0, dp(8), 0, dp(30));
        sc.addView(list);
        addSetting(list, "SET AS DEFAULT HOME", this::requestHomeRole, "Open Android's Home app selection dialog");
        addSetting(list, "NOTIFICATION ACCESS", () -> openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), "Optional badge / notification integration");
        addSetting(list, "USAGE ACCESS", () -> openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS), "Optional app usage statistics access");
        addSetting(list, "CHANGE WALLPAPER", this::pickWallpaper, "Choose a picture from your device");
        addSetting(list, "RESET CLOCK POSITION", this::resetPositions, "Move time and date back to center");
        addSetting(list, "ALL APPS", this::showDrawer, "Open full app drawer");
        addSetting(list, "ABOUT", () -> new AlertDialog.Builder(this).setTitle("DARK LUXURY 1.1")
                .setMessage("Black & Gold • No ads\nLong press menu • Draggable time/date\nLuxury icon pack assets included")
                .setPositiveButton("OK", null).show(), "Launcher information");
    }

    private void addSetting(LinearLayout list, String title, Runnable run, String detail) {
        LinearLayout block = column();
        block.setPadding(dp(14), dp(14), dp(14), dp(14));
        block.setBackground(panelBg(PANEL, 16, true));
        TextView heading = text(title, 13, GOLD, true);
        block.addView(heading);
        TextView d = text(detail, 12, MUTED, false);
        d.setPadding(0, dp(6), 0, 0);
        block.addView(d);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(11), 0, 0);
        list.addView(block, p);
        block.setOnClickListener(v -> run.run());
    }

    private void resetPositions() {
        prefs().edit().putFloat("clock_x", 0).putFloat("clock_y", 0).putFloat("date_x", 0).putFloat("date_y", 0).apply();
        if (clock != null) {
            clock.setTranslationX(0); clock.setTranslationY(0);
        }
        if (dateText != null) {
            dateText.setTranslationX(0); dateText.setTranslationY(0);
        }
        Toast.makeText(this, "Clock and date reset", Toast.LENGTH_SHORT).show();
    }

    private void showWelcome() {
        new AlertDialog.Builder(this)
                .setTitle("Welcome to DARK LUXURY")
                .setMessage("Long press on the home screen to open the launcher menu. You can drag the time and date anywhere, open apps quickly, and set DARK LUXURY as your default Home app.")
                .setPositiveButton("SET DEFAULT HOME", (d, w) -> requestHomeRole())
                .setNegativeButton("LATER", null)
                .show();
    }

    private void requestHomeRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager roles = (RoleManager) getSystemService(ROLE_SERVICE);
            if (roles != null && roles.isRoleAvailable(RoleManager.ROLE_HOME)) {
                if (roles.isRoleHeld(RoleManager.ROLE_HOME)) {
                    Toast.makeText(this, "Already the default Home app", Toast.LENGTH_SHORT).show();
                    return;
                }
                startActivityForResult(roles.createRequestRoleIntent(RoleManager.ROLE_HOME), 125);
                return;
            }
        }
        openSettings(Settings.ACTION_HOME_SETTINGS);
    }

    private void openSettings(String action) {
        try {
            startActivity(new Intent(action));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Settings screen unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    private void pickWallpaper() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(i, PICK_WALLPAPER);
        } catch (Exception e) {
            Toast.makeText(this, "Photo picker unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_WALLPAPER && result == RESULT_OK && data != null && data.getData() != null) {
            try {
                WallpaperManager.getInstance(this).setStream(getContentResolver().openInputStream(data.getData()));
                Toast.makeText(this, "Wallpaper changed", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Could not change wallpaper", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override public void onBackPressed() {
        if (inSubPage) buildHome();
        else super.onBackPressed();
    }
}
