package com.blacktouch.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.File;
import java.util.*;

public class MainActivity extends Activity {
  private LinearLayout page;
  private final int WHITE=Color.WHITE, MUTED=Color.rgb(175,185,205);
  private List<ApplicationInfo> apps = new ArrayList<>();
  private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
  private GradientDrawable panel(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);loadApps();home();}
  private void loadApps(){
    PackageManager pm=getPackageManager(); apps.clear();
    Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(Intent.CATEGORY_LAUNCHER);
    Set<String> found=new HashSet<>();
    for(android.content.pm.ResolveInfo r:pm.queryIntentActivities(intent,0)) {
      String p=r.activityInfo.packageName;
      if(!p.equals(getPackageName()) && found.add(p)) try {apps.add(pm.getApplicationInfo(p,0));}catch(Exception ignored){}
    }
    Collections.sort(apps,(a,b)->a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
  }
  private TextView text(String t,int size,boolean bold){TextView v=new TextView(this);v.setText(t);v.setTextColor(WHITE);v.setTextSize(size);if(bold)v.setTypeface(null,Typeface.BOLD);return v;}
  private void init(String heading){
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(5,7,12));
    page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(20),dp(28),dp(20),dp(36));scroll.addView(page);setContentView(scroll);
    TextView title=text(heading,28,true);page.addView(title);space(12);
  }
  private void space(int h){View s=new View(this);page.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
  private void action(String label,Runnable run){
    TextView v=text(label,16,false);v.setPadding(dp(18),dp(16),dp(16),dp(16));v.setBackground(panel(Color.rgb(24,29,42),16));
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);page.addView(v,p);v.setOnClickListener(w->run.run());
  }
  private void home(){
    init("BlackTouch");TextView sub=text("Glass 3D · Midnight",13,false);sub.setTextColor(MUTED);page.addView(sub);space(24);
    action("All Apps  ›",()->listApps("All Apps",apps));
    action("Games  ›",()->folder("Games"));
    action("Google  ›",()->folder("Google"));
    action("Settings  ›",this::settings);
    space(12);TextView hint=text("Tap an app to launch · English interface",13,false);hint.setTextColor(MUTED);page.addView(hint);
  }
  private void folder(String name){List<ApplicationInfo> selected=new ArrayList<>();
    for(ApplicationInfo a:apps){String p=a.packageName.toLowerCase(Locale.ROOT);String label=a.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
      boolean google=p.startsWith("com.google.")||p.contains("youtube")||p.contains("gmail");
      boolean game=(a.category==ApplicationInfo.CATEGORY_GAME)||p.contains("game")||label.contains("game");
      if(name.equals("Google")?google:game)selected.add(a);
    }listApps(name,selected);
  }
  private void listApps(String heading,List<ApplicationInfo> items){
    init(heading);action("‹ Back",this::home);
    if(items.isEmpty()){TextView empty=text("No apps in this folder yet.",14,false);empty.setTextColor(MUTED);page.addView(empty);return;}
    for(ApplicationInfo a:items){String label=a.loadLabel(getPackageManager()).toString();
      TextView row=text(label,16,false);row.setPadding(dp(14),dp(11),dp(10),dp(11));
      android.graphics.drawable.Drawable icon=a.loadIcon(getPackageManager());icon.setBounds(0,0,dp(36),dp(36));row.setCompoundDrawables(icon,null,null,null);row.setCompoundDrawablePadding(dp(14));
      page.addView(row,new LinearLayout.LayoutParams(-1,dp(60)));
      row.setOnClickListener(v->{Intent i=getPackageManager().getLaunchIntentForPackage(a.packageName);if(i!=null)startActivity(i);});
    }
  }
  private void settings(){
    init("Settings");action("‹ Home",this::home);
    action("Clear Launcher Cache",()->{
      long bytes=clearDir(getCacheDir());
      if(android.os.Build.VERSION.SDK_INT>=21)bytes+=clearDir(getCodeCacheDir());
      Toast.makeText(this,"Launcher cache cleared ("+(bytes/1024)+" KB)",Toast.LENGTH_LONG).show();
    });
    action("Manage Other Apps' Storage",()->{
      try{startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));}
      catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}
    });
    action("Set Default Home App",()->{
      try{startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));}
      catch(Exception e){Toast.makeText(this,"Open Android Settings > Default apps > Home app",Toast.LENGTH_LONG).show();}
    });
    action("Refresh App List",()->{loadApps();Toast.makeText(this,"App list refreshed",Toast.LENGTH_SHORT).show();home();});
    space(16);TextView note=text("Android does not permit a regular launcher to silently clear every other app's cache. Use Manage Other Apps' Storage to clear cache in Android Settings.",13,false);note.setTextColor(MUTED);page.addView(note);
  }
  private long clearDir(File f){long total=0;File[] list=f.listFiles();if(list==null)return 0;for(File x:list){if(x.isDirectory())total+=clearDir(x);else total+=x.length();x.delete();}return total;}
  @Override public void onBackPressed(){home();}
}
