BlackTouch English + Clear Cache Android Studio source project

Open this directory in Android Studio, allow Gradle sync, choose Build > Build APK(s).
The main user interface is in English. Settings includes Clear Launcher Cache, which deletes this launcher's own cache, and Manage Other Apps' Storage, which opens Android system storage settings.
Android does not allow a normal third-party launcher to silently clear every other app's cache.

This is a reconstructed source project using the original uploaded APK's 36 glass icon assets, not a decompiled or modified version of the original app. The icons are preserved in app/src/main/assets/glass/.
