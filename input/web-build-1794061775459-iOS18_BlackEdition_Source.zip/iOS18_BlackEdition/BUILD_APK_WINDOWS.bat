@echo off
setlocal
cd /d "%~dp0"
title iOS18 Black Edition - APK Builder

echo ==========================================
echo       iOS18 BLACK EDITION - APK BUILD
 echo ==========================================
echo.

if not defined ANDROID_HOME (
  if exist "%LOCALAPPDATA%\Android\Sdk\platforms\android-35\android.jar" (
    set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
  )
)
if not defined ANDROID_HOME (
  echo [XATO] Android SDK topilmadi.
  echo Android Studio o'rnating va SDK Manager'dan Android API 35 ni yuklang.
  pause
  exit /b 1
)

if not defined JAVA_HOME (
  if exist "C:\Program Files\Android\Android Studio\jbr\bin\java.exe" (
    set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
  )
)

set "GRADLE_DIR=%CD%\.tools\gradle-8.9"
if not exist "%GRADLE_DIR%\bin\gradle.bat" (
  echo Gradle 8.9 birinchi marta yuklanmoqda. Internet kerak.
  if not exist ".tools" mkdir ".tools"
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile '.tools\gradle-8.9-bin.zip'; Expand-Archive -Path '.tools\gradle-8.9-bin.zip' -DestinationPath '.tools' -Force"
  if errorlevel 1 (
    echo [XATO] Gradle yuklanmadi. Internetni tekshiring.
    pause
    exit /b 1
  )
)

echo APK build boshlanmoqda...
call "%GRADLE_DIR%\bin\gradle.bat" :app:assembleDebug --no-daemon
if errorlevel 1 (
  echo [XATO] APK yig'ib bo'lmadi. Yuqoridagi xatoni ko'ring.
  pause
  exit /b 1
)

echo.
echo [TAYYOR] app\build\outputs\apk\debug\app-debug.apk
explorer "%CD%\app\build\outputs\apk\debug"
pause
