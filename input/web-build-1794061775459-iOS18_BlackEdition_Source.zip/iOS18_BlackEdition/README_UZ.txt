iOS 18 BLACK EDITION — YANGI, REKLAMASIZ ANDROID LAUNCHER
=======================================================

DIQQAT: BU ZIP — ANDROID STUDIO MANBA KODI, TAYYOR APK EMAS.
Uni ZIP -> APK saytida shunchaki formatini o‘zgartirib o‘rnatib bo‘lmaydi.

BU NIMA?
Yuborgan "Launcher iOS 16" (6.2.5) APK fayli original yopiq kodli dastur.
Uning ichida reklama (Google Mobile Ads SDK) bor. Asl dastur manba kodi
bo‘lmagani uchun "barcha funksiyalarini olib, reklamasini o‘chirdim" deyish
noto‘g‘ri bo‘lardi. Ushbu paket unga qo‘shimcha sifatida ishlab chiqilgan,
ALOHiDA, original Android HOME launcher kodi. Oldingi APK qayta yig‘ilmadi.

LAUNCHER IMKONIYATLARI:
• iOS 18 nomi, maxsus original qora iOS18 logo (Apple belgisisiz)
• AMOLED qora / Obsidian / Carbon / Noir / Midnight / Graphite Black dizayni
• Ilovalar ro‘yxati: qidirish va 4/5 ustunli ko‘rinish
• Ilova ikonlarini oq-qora yoki rangli ko‘rsatish
• Pastdagi 4 ta sevimli ilova / ilovalarni yashirish
• Soat, sana, batareya foizi, telefon sozlamalariga tezkor o‘tish
• Galereyadan fon rasmi tanlash; tanlangan rasmni Android foniga ham qo‘yish
• Birinchi ishga tushishda standart HOME sifatida tanlash oynasiga o‘tish
• Internet ruxsati yo‘q, reklamalar SDKsi yo‘q, fonda reklama so‘rovlar yo‘q
• Android 10 / 4GB RAM uchun yengil Java kod

NEGA RUXSAT POPUPI CHIQMASLIGI MUMKIN?
- Standart HOME ilova ruxsati Android RoleManager orqali tizim oynasida
  tanlanadi. Dastur boshqa launcherni kuch bilan almashtira olmaydi.
- Galereya tanlash Androidning tizim fayl tanlagichi orqali ishlaydi.
  Umumiy galereyaga kirish uchun xavfli keng ruxsat talab etilmaydi.
- SET_WALLPAPER "normal" ruxsat, alohida popup bilan berilmaydi.

ANDROID 10 DA DOIMIY LAUNCHER QILISH
1. APKni to‘g‘ri yig‘ib, telefonga o‘rnating.
2. iOS 18 ni oching.
3. Birinchi oynada "Standart launcher qilish" ni bosing.
4. Tizim tanlash oynasida "iOS 18" ni tanlang va tasdiqlang.
5. Tizim oynasi chiqmasa:
   Sozlamalar > Ilovalar > Standart ilovalar > Bosh ekran > iOS 18.
   (Ishlab chiqaruvchiga qarab menyu nomlari farq qiladi.)
6. Eski launcherga qaytish uchun o‘sha menyudan eski ilovani tanlang.

APKNI YIG‘ISH
Variant A — kompyuter:
1. Android Studio o‘rnating: https://developer.android.com/studio
2. ZIPni oching, loyiha papkasini Android Studio bilan Open qiling.
3. Android SDK 35 ni o‘rnating, Gradle syncni tugating.
4. Build > Build APK(s) > app-debug.apk.
5. app/build/outputs/apk/debug/app-debug.apk ni telefonga o‘rnating.

Variant B — Google Colab:
1. Ilova bilan berilgan iOS18_Build_APK_Colab.ipynb faylini
   https://colab.research.google.com da Upload notebook qiling.
2. ▶ ni bosib iOS18_BlackEdition_Source.zip ni tanlang.
3. Tizim SDK/Gradle yuklaydi; yig‘ish muvaffaqiyatli bo‘lsa APK yuklanadi.
   Colab internetiga va SDK saytlariga ulanish talab qilinadi.

Muqobil variant — .github/workflows/build-apk.yml Github Actions workflow.
GitHub tokenni AndroidForge kabi uchinchi tomon saytiga berish shart emas.

Sinov holati: Zip manbalari/strukturasi tekshirilgan. Hozirgi muhitda SDK
mavjud emas, shuning uchun APKni yig‘ib, Android telefonida sinab bo‘lmadi.

Muhim: Apple iOS tizimining o‘zi emas, Android launcher. Boshqa
ilovalarning ichki mavzularini majburan o‘zgartira olmaydi.
