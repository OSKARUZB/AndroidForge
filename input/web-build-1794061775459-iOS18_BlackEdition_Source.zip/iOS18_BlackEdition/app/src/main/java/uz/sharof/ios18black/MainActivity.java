package uz.sharof.ios18black;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.app.role.RoleManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.BatteryManager;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * iOS 18 BLACK EDITION: Android 10 friendly, original, ad-free Home launcher.
 * Only user-chosen storage is read; no internet, trackers, overlays or services.
 */
public class MainActivity extends Activity {
    private static final int PICK_WALLPAPER = 201;
    private static final int SET_HOME_ROLE = 202;
    private static final String PREF = "ios18_black_edition";
    private static final String KEY_THEME = "theme";
    private static final String KEY_FAVORITES = "favorite_components";
    private static final String KEY_HIDDEN = "hidden_components";
    private static final String WALLPAPER_NAME = "ios18_wallpaper.jpg";

    private static final String[] THEME_NAMES = {
            "AMOLED 18", "Obsidian", "Carbon", "Noir", "Midnight", "Graphite Black"
    };
    // Every theme is black/graphite; no bright color backgrounds.
    // [background top, background bottom, accent, tile]
    private static final int[][] COLORS = {
            {0xFF000000, 0xFF000000, 0xFFFFFFFF, 0xFF101012},
            {0xFF08080A, 0xFF000000, 0xFFEDEDF2, 0xFF171719},
            {0xFF111214, 0xFF030303, 0xFFDFDFDF, 0xFF1C1C1E},
            {0xFF050505, 0xFF000000, 0xFFF9F9F9, 0xFF151515},
            {0xFF0B0C0F, 0xFF000000, 0xFFD3D5DA, 0xFF18191C},
            {0xFF1A1A1D, 0xFF020202, 0xFFE6E6E7, 0xFF242428}
    };
    private static final int TOP = 0, BOTTOM = 1, ACCENT = 2, TILE = 3;
    private static final int WHITE = 0xFFF7F7FA, DIM = 0xFFABABB8;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<AppEntry> installed = new ArrayList<>();
    private SharedPreferences preferences;
    private FrameLayout root;
    private View drawerView;
    private TextView clockView, dateView;
    private Bitmap wallpaper;
    private boolean drawerVisible;
    private boolean showHidden;
    private boolean previouslyDefault;
    private int theme;
    private long lastAppRefresh;

    private final Runnable clockRunner = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 30_000);
        }
    };

    static class AppEntry {
        String name;
        String pkg;
        String cls;
        Drawable icon;
        String id() { return pkg + "/" + cls; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences(PREF, MODE_PRIVATE);
        theme = Math.max(0, Math.min(THEME_NAMES.length - 1, preferences.getInt(KEY_THEME, 0)));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        loadWallpaper();
        loadApps();
        previouslyDefault = isDefaultHome();
        render();
        showFirstRunHomeDialog();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(clockRunner);
        handler.post(clockRunner);
        boolean nowDefault = isDefaultHome();
        boolean changed = nowDefault != previouslyDefault;
        previouslyDefault = nowDefault;
        if (changed || System.currentTimeMillis() - lastAppRefresh > 30_000) {
            loadApps();
            render();
        }
    }

    @Override protected void onPause() {
        handler.removeCallbacks(clockRunner);
        super.onPause();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        render();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        render(); // The Home key always returns to the home page.
    }

    @Override public void onBackPressed() {
        if (drawerVisible) closeDrawer();
        else { /* Home must stay open; the system handles task navigation. */ }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_WALLPAPER && result == RESULT_OK && data != null && data.getData() != null) {
            saveSelectedWallpaper(data.getData());
        } else if (request == SET_HOME_ROLE) {
            previouslyDefault = isDefaultHome();
            render();
            Toast.makeText(this, previouslyDefault ? "iOS 18 standart launcher bo‘ldi" :
                    "Standart launcher tanlanmadi", Toast.LENGTH_LONG).show();
        }
    }

    private String batteryPercent() {
        try {
            Intent status = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (status != null) {
                int level = status.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = status.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) return Math.round(level * 100f / scale) + "%";
            }
        } catch (Exception ignored) { }
        return "—";
    }

    private void launchAndroidSettings() {
        try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        catch (Exception e) { Toast.makeText(this, "Sozlamalar ochilmadi", Toast.LENGTH_SHORT).show(); }
    }

    private void showFirstRunHomeDialog() {
        if (preferences.getBoolean("onboarding_shown", false)) return;
        preferences.edit().putBoolean("onboarding_shown", true).apply();
        root.post(() -> new AlertDialog.Builder(MainActivity.this)
                .setTitle("iOS 18 Black Edition")
                .setMessage("Bosh ekran tugmasini bosganda iOS 18 ochilishi uchun uni telefonning standart Home ilovasi sifatida tanlang. Bu Android tizim oynasi orqali tasdiqlanadi. Rasm tanlash uchun esa galereya oynasi ochiladi.")
                .setPositiveButton("Standart launcher qilish", (d, w) -> requestDefaultHome())
                .setNegativeButton("Keyinroq", null)
                .show());
    }

    private int dp(float x) { return (int) (x * getResources().getDisplayMetrics().density + 0.5f); }
    private int color(int part) { return COLORS[theme][part]; }
    private boolean monochrome() { return preferences.getBoolean("mono_icons", true); }
    private boolean showLabels() { return preferences.getBoolean("show_labels", true); }
    private int drawerColumns() { return preferences.getInt("drawer_columns", 4); }
    private File wallpaperFile() { return new File(getFilesDir(), WALLPAPER_NAME); }

    private GradientDrawable rounded(int fill, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(fill);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(s);
        view.setTextColor(color);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        view.setIncludeFontPadding(false);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private TextView pill(String value) {
        TextView t = text(value, 13, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        t.setBackground(rounded(0xE51A1A20, 18));
        return t;
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> result = pm.queryIntentActivities(query, 0);
        ArrayList<AppEntry> next = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo info : result) {
            if (info.activityInfo == null) continue;
            if (getPackageName().equals(info.activityInfo.packageName)) continue;
            AppEntry entry = new AppEntry();
            entry.pkg = info.activityInfo.packageName;
            entry.cls = info.activityInfo.name;
            if (!seen.add(entry.id())) continue;
            CharSequence name = info.loadLabel(pm);
            entry.name = name == null ? entry.pkg : name.toString();
            try { entry.icon = info.loadIcon(pm); } catch (Exception ignored) { }
            next.add(entry);
        }
        Collections.sort(next, new Comparator<AppEntry>() {
            @Override public int compare(AppEntry a, AppEntry b) {
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        installed.clear();
        installed.addAll(next);
        lastAppRefresh = System.currentTimeMillis();
    }

    private boolean isDefaultHome() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager role = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (role != null && role.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    return role.isRoleHeld(RoleManager.ROLE_HOME);
                }
            }
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            ResolveInfo info = getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            return info != null && info.activityInfo != null
                    && getPackageName().equals(info.activityInfo.packageName);
        } catch (Exception e) { return false; }
    }

    private void requestDefaultHome() {
        if (isDefaultHome()) {
            Toast.makeText(this, "Launcher allaqachon standart", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager role = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (role != null && role.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    startActivityForResult(role.createRequestRoleIntent(RoleManager.ROLE_HOME), SET_HOME_ROLE);
                    return;
                }
            }
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "Sozlamalar > Ilovalar > Standart ilovalar > Bosh ekran", Toast.LENGTH_LONG).show();
        }
    }

    private void loadWallpaper() {
        wallpaper = null;
        File file = wallpaperFile();
        if (!file.exists()) return;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        options.inSampleSize = sampleSize(options.outWidth, options.outHeight, 1600);
        options.inJustDecodeBounds = false;
        try { wallpaper = BitmapFactory.decodeFile(file.getAbsolutePath(), options); }
        catch (OutOfMemoryError ignored) { wallpaper = null; }
    }

    private int sampleSize(int width, int height, int maxSide) {
        int factor = 1;
        while (width / factor > maxSide || height / factor > maxSide) factor *= 2;
        return factor;
    }

    private void chooseWallpaper() {
        try {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("image/*");
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(pick, PICK_WALLPAPER);
        } catch (Exception e) {
            Toast.makeText(this, "Telefoningizdan rasm tanlash oynasi ochilmadi", Toast.LENGTH_LONG).show();
        }
    }

    private void saveSelectedWallpaper(Uri uri) {
        // Decode sampled to avoid crashing older 4 GB RAM devices on very large photos.
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream input = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(input, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new Exception("Invalid photo");
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, 1600);
            Bitmap selected;
            try (InputStream input = getContentResolver().openInputStream(uri)) {
                selected = BitmapFactory.decodeStream(input, null, opts);
            }
            if (selected == null) throw new Exception("Cannot decode");
            // Save a small, local wallpaper; gallery-wide access is never needed.
            try (FileOutputStream output = new FileOutputStream(wallpaperFile())) {
                if (!selected.compress(Bitmap.CompressFormat.JPEG, 85, output))
                    throw new Exception("Cannot save photo");
            }
            wallpaper = selected;
            render();
            new AlertDialog.Builder(this)
                    .setTitle("Rasm qo‘yildi")
                    .setMessage("Rasm launcher foniga o‘rnatildi. Telefonning asosiy foniga ham qo‘yamizmi?")
                    .setPositiveButton("Telefon foniga ham", (d, w) -> applySystemWallpaper())
                    .setNegativeButton("Faqat launcher", null).show();
        } catch (Exception | OutOfMemoryError e) {
            Toast.makeText(this, "Rasm ochilmadi. Boshqa JPG/PNG tanlang.", Toast.LENGTH_LONG).show();
        }
    }

    private void applySystemWallpaper() {
        if (wallpaper == null) {
            Toast.makeText(this, "Avval galereyadan rasm tanlang", Toast.LENGTH_SHORT).show();
            return;
        }
        final Bitmap selected = wallpaper;
        new Thread(() -> {
            boolean ok = false;
            try {
                WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
                if (Build.VERSION.SDK_INT >= 24) {
                    if (manager.isSetWallpaperAllowed()) {
                        manager.setBitmap(selected, null, false, WallpaperManager.FLAG_SYSTEM);
                        ok = true;
                    }
                } else {
                    manager.setBitmap(selected);
                    ok = true;
                }
            } catch (Exception | OutOfMemoryError ignored) { }
            final boolean success = ok;
            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    success ? "Telefon foni ham o‘zgardi" : "Telefon fonini o‘zgartirishga ruxsat berilmadi",
                    Toast.LENGTH_LONG).show());
        }).start();
    }

    private void removeWallpaper() {
        wallpaperFile().delete();
        wallpaper = null;
        render();
        Toast.makeText(this, "Qora fon tiklandi", Toast.LENGTH_SHORT).show();
    }

    private void render() {
        drawerVisible = false;
        drawerView = null;
        Window window = getWindow();
        window.setStatusBarColor(Color.BLACK);
        window.setNavigationBarColor(Color.BLACK);
        window.getDecorView().setSystemUiVisibility(0);
        root = new FrameLayout(this);
        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[] {color(TOP), color(BOTTOM)});
        root.setBackground(gradient);
        setContentView(root);
        if (wallpaper != null && !wallpaper.isRecycled()) {
            ImageView background = new ImageView(this);
            background.setImageBitmap(wallpaper);
            background.setScaleType(ImageView.ScaleType.CENTER_CROP);
            root.addView(background, new FrameLayout.LayoutParams(-1, -1));
            View shade = new View(this);
            shade.setBackgroundColor(0x7D000000);
            root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        }
        GestureDetector gestures = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                if (a != null && b != null && a.getY() - b.getY() > dp(65)) {
                    openDrawer(); return true;
                }
                return false;
            }
        });
        root.setOnTouchListener((v, event) -> gestures.onTouchEvent(event));

        LinearLayout home = column();
        home.setPadding(dp(19), dp(17), dp(19), dp(18));
        root.addView(home, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        home.addView(header, new LinearLayout.LayoutParams(-1, dp(51)));
        TextView brand = text("iOS 18  •  BLACK EDITION", 15, WHITE, true);
        brand.setLetterSpacing(.04f);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView settings = pill("⚙  Sozlamalar");
        settings.setOnClickListener(v -> showSettings());
        header.addView(settings);

        TextView roleNotice = text(isDefaultHome() ? "✓  Standart bosh ekran" :
                "●  iOS 18 ni standart launcher qilish uchun bosing", 12,
                isDefaultHome() ? 0xFFBAF7C9 : 0xFFFFD396, true);
        roleNotice.setGravity(Gravity.CENTER_VERTICAL);
        roleNotice.setPadding(dp(7), dp(8), dp(7), dp(8));
        roleNotice.setOnClickListener(v -> requestDefaultHome());
        LinearLayout.LayoutParams roleParams = new LinearLayout.LayoutParams(-1, dp(35));
        roleParams.topMargin = dp(8);
        home.addView(roleNotice, roleParams);

        home.addView(new View(this), new LinearLayout.LayoutParams(1, dp(32)));
        clockView = text("", 68, WHITE, true);
        clockView.setLetterSpacing(-0.05f);
        home.addView(clockView);
        dateView = text("", 15, 0xFFE0E0E5, false);
        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(-1, -2);
        dateParams.topMargin = dp(6);
        home.addView(dateView, dateParams);
        updateClock();

        LinearLayout widgets = new LinearLayout(this);
        widgets.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams widgetParams = new LinearLayout.LayoutParams(-1, dp(44));
        widgetParams.topMargin = dp(18);
        home.addView(widgets, widgetParams);
        TextView batteryWidget = pill("▰  Batareya " + batteryPercent());
        widgets.addView(batteryWidget, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout.LayoutParams spacerWidget = new LinearLayout.LayoutParams(dp(10), -1);
        widgets.addView(new View(this), spacerWidget);
        TextView quickSettings = pill("⚙  Tizim");
        quickSettings.setOnClickListener(v -> launchAndroidSettings());
        widgets.addView(quickSettings, new LinearLayout.LayoutParams(0, -1, 1));

        LinearLayout shortcuts = new LinearLayout(this);
        shortcuts.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams quickParams = new LinearLayout.LayoutParams(-1, dp(49));
        quickParams.topMargin = dp(27);
        home.addView(shortcuts, quickParams);
        TextView photo = pill("▧  Fon rasmi");
        photo.setOnClickListener(v -> chooseWallpaper());
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, -1, 1);
        p1.rightMargin = dp(10);
        shortcuts.addView(photo, p1);
        TextView themes = pill("◉  Mavzular");
        themes.setOnClickListener(v -> showThemes());
        shortcuts.addView(themes, new LinearLayout.LayoutParams(0, -1, 1));

        home.addView(new View(this), new LinearLayout.LayoutParams(1, 0, 1));
        TextView slogan = text("iOS 18  •  BLACK EDITION  •  AD FREE", 10, 0xFFCBCBD4, true);
        slogan.setLetterSpacing(.12f);
        slogan.setGravity(Gravity.CENTER);
        home.addView(slogan, new LinearLayout.LayoutParams(-1, dp(35)));

        LinearLayout dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER);
        dock.setBackground(rounded(0xE509090C, 23));
        LinearLayout.LayoutParams dpParams = new LinearLayout.LayoutParams(-1, dp(103));
        dpParams.bottomMargin = dp(13);
        home.addView(dock, dpParams);
        List<AppEntry> favorites = dockApps();
        for (int i = 0; i < 4; i++) {
            if (i < favorites.size()) {
                dock.addView(appCell(favorites.get(i), true, dp(70)),
                        new LinearLayout.LayoutParams(0, -1, 1));
            } else {
                TextView add = text("+", 26, color(ACCENT), true);
                add.setGravity(Gravity.CENTER);
                add.setOnClickListener(v -> openDrawer());
                dock.addView(add, new LinearLayout.LayoutParams(0, -1, 1));
            }
        }
        TextView allApps = text("☰   BARCHA ILOVALAR    ↑", 15, WHITE, true);
        allApps.setGravity(Gravity.CENTER);
        allApps.setBackground(rounded(0xEF101014, 17));
        allApps.setOnClickListener(v -> openDrawer());
        home.addView(allApps, new LinearLayout.LayoutParams(-1, dp(56)));
    }

    private List<AppEntry> dockApps() {
        ArrayList<AppEntry> chosen = new ArrayList<>();
        Set<String> ids = preferences.getStringSet(KEY_FAVORITES, Collections.emptySet());
        for (AppEntry e : installed) {
            if (ids.contains(e.id()) && !chosen.contains(e)) chosen.add(e);
            if (chosen.size() == 4) return chosen;
        }
        String[] preferred = {"com.whatsapp", "org.telegram.messenger", "com.android.chrome",
                "com.google.android.dialer", "com.android.dialer", "com.android.camera"};
        for (String pkg : preferred) {
            for (AppEntry e : installed) {
                if (e.pkg.equals(pkg) && !chosen.contains(e)) chosen.add(e);
                if (chosen.size() == 4) return chosen;
            }
        }
        for (AppEntry e : installed) {
            if (!chosen.contains(e)) chosen.add(e);
            if (chosen.size() == 4) break;
        }
        return chosen;
    }

    private View appCell(AppEntry app, boolean dock, int cellWidth) {
        LinearLayout cell = column();
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(dp(2), dp(5), dp(2), dp(5));
        cell.setMinimumWidth(cellWidth);
        FrameLayout plate = new FrameLayout(this);
        plate.setBackground(rounded(0xFF18181D, 17));
        int side = dp(dock ? 56 : 60);
        cell.addView(plate, new LinearLayout.LayoutParams(side, side));
        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (app.icon != null) {
            icon.setImageDrawable(app.icon);
            if (monochrome()) icon.setColorFilter(WHITE, PorterDuff.Mode.SRC_IN);
        }
        int margin = dp(dock ? 7 : 9);
        FrameLayout.LayoutParams iParams = new FrameLayout.LayoutParams(-1, -1);
        iParams.setMargins(margin, margin, margin, margin);
        plate.addView(icon, iParams);
        if (showLabels()) {
            TextView name = text(app.name, 10.5f, 0xFFEAEAF0, false);
            name.setGravity(Gravity.CENTER);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams nParams = new LinearLayout.LayoutParams(-1, dp(21));
            nParams.topMargin = dp(3);
            cell.addView(name, nParams);
        }
        cell.setOnClickListener(v -> openApp(app));
        cell.setOnLongClickListener(v -> { appOptions(app); return true; });
        cell.setContentDescription(app.name + " ilovasi");
        return cell;
    }

    private void openApp(AppEntry app) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setComponent(new ComponentName(app.pkg, app.cls));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
        } catch (Exception e) { Toast.makeText(this, "Ilova ochilmadi", Toast.LENGTH_SHORT).show(); }
    }

    private void toggleFavorite(AppEntry app) {
        Set<String> ids = new HashSet<>(preferences.getStringSet(KEY_FAVORITES, Collections.emptySet()));
        if (ids.contains(app.id())) ids.remove(app.id());
        else if (ids.size() < 4) ids.add(app.id());
        else {
            Toast.makeText(this, "Pastki panelda eng ko‘pi 4 ta ilova", Toast.LENGTH_LONG).show();
            return;
        }
        preferences.edit().putStringSet(KEY_FAVORITES, ids).apply();
        render();
    }

    private void toggleHidden(AppEntry app) {
        Set<String> hidden = new HashSet<>(preferences.getStringSet(KEY_HIDDEN, Collections.emptySet()));
        if (hidden.contains(app.id())) hidden.remove(app.id());
        else hidden.add(app.id());
        preferences.edit().putStringSet(KEY_HIDDEN, hidden).apply();
        if (drawerVisible) { closeDrawer(); openDrawer(); }
        else render();
    }

    private void appOptions(AppEntry app) {
        boolean pinned = preferences.getStringSet(KEY_FAVORITES, Collections.emptySet()).contains(app.id());
        boolean hidden = preferences.getStringSet(KEY_HIDDEN, Collections.emptySet()).contains(app.id());
        String[] actions = {
                pinned ? "Dockdan olib tashlash" : "Dockga qo‘shish",
                hidden ? "Ilovani qayta ko‘rsatish" : "Ilovani yashirish",
                "Ilova ma'lumoti"
        };
        new AlertDialog.Builder(this).setTitle(app.name).setItems(actions, (dialog, choice) -> {
            if (choice == 0) toggleFavorite(app);
            else if (choice == 1) toggleHidden(app);
            else {
                try {
                    Intent details = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + app.pkg));
                    startActivity(details);
                } catch (Exception ignored) { }
            }
        }).setNegativeButton("Yopish", null).show();
    }

    private void openDrawer() {
        if (drawerVisible) return;
        drawerVisible = true;
        LinearLayout sheet = column();
        sheet.setPadding(dp(12), dp(16), dp(12), dp(6));
        sheet.setBackground(rounded(0xFF050507, 23));
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, -1);
        params.topMargin = dp(55);
        params.leftMargin = dp(4);
        params.rightMargin = dp(4);
        root.addView(sheet, params);
        drawerView = sheet;
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        sheet.addView(header, new LinearLayout.LayoutParams(-1, dp(43)));
        TextView close = text("‹", 32, WHITE, true);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> closeDrawer());
        header.addView(close, new LinearLayout.LayoutParams(dp(42), -1));
        TextView title = text("Barcha ilovalar", 21, WHITE, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView reload = pill("↻");
        reload.setOnClickListener(v -> { loadApps(); closeDrawer(); openDrawer(); });
        header.addView(reload);

        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(WHITE);
        search.setHintTextColor(DIM);
        search.setHint("Ilovalarni qidirish...");
        search.setTextSize(14);
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackground(rounded(0xFF17171D, 14));
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(50));
        searchParams.topMargin = dp(10);
        searchParams.bottomMargin = dp(10);
        sheet.addView(search, searchParams);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        sheet.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(drawerColumns());
        grid.setPadding(0, dp(2), 0, dp(20));
        scroll.addView(grid);
        fillApps(grid, "");
        TextView help = text("Uzoq bosish: dock, yashirish yoki ilova ma'lumoti", 11, DIM, false);
        help.setGravity(Gravity.CENTER);
        help.setOnClickListener(v -> showSettings());
        sheet.addView(help, new LinearLayout.LayoutParams(-1, dp(42)));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence value, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence value, int start, int before, int count) {
                fillApps(grid, value.toString());
                scroll.scrollTo(0, 0);
            }
            @Override public void afterTextChanged(Editable value) { }
        });
    }

    private void fillApps(GridLayout grid, String filter) {
        grid.removeAllViews();
        Set<String> hidden = preferences.getStringSet(KEY_HIDDEN, Collections.emptySet());
        String needle = filter.trim().toLowerCase(Locale.getDefault());
        int count = 0;
        int columns = drawerColumns();
        int available = getResources().getDisplayMetrics().widthPixels - dp(39);
        int cellWidth = available / columns;
        for (AppEntry app : installed) {
            if (!showHidden && hidden.contains(app.id())) continue;
            if (!app.name.toLowerCase(Locale.getDefault()).contains(needle)) continue;
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = cellWidth;
            gp.height = dp(showLabels() ? 108 : 82);
            gp.rowSpec = GridLayout.spec(count / columns);
            gp.columnSpec = GridLayout.spec(count % columns);
            grid.addView(appCell(app, false, cellWidth), gp);
            count++;
        }
        if (count == 0) {
            TextView empty = text("Hech qanday ilova topilmadi", 15, DIM, false);
            empty.setGravity(Gravity.CENTER);
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = available;
            gp.height = dp(94);
            gp.rowSpec = GridLayout.spec(0);
            gp.columnSpec = GridLayout.spec(0, columns);
            grid.addView(empty, gp);
        }
    }

    private void closeDrawer() {
        if (drawerView != null) {
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(drawerView.getWindowToken(), 0);
            root.removeView(drawerView);
            drawerView = null;
        }
        drawerVisible = false;
    }

    private void showThemes() {
        new AlertDialog.Builder(this).setTitle("Qora mavzular")
                .setSingleChoiceItems(THEME_NAMES, theme, (dialog, index) -> {
                    theme = index;
                    preferences.edit().putInt(KEY_THEME, index).apply();
                    dialog.dismiss();
                    render();
                }).setNegativeButton("Yopish", null).show();
    }

    private void addSetting(LinearLayout target, String heading, String description, Runnable action) {
        LinearLayout card = column();
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        card.setBackground(rounded(0xFF19191F, 13));
        TextView main = text(heading, 15, WHITE, true);
        card.addView(main);
        TextView sub = text(description, 12, DIM, false);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-1, -2);
        subp.topMargin = dp(4);
        card.addView(sub, subp);
        LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(-1, -2);
        outer.bottomMargin = dp(8);
        target.addView(card, outer);
        card.setOnClickListener(v -> action.run());
    }

    private void showSettings() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        LinearLayout items = column();
        items.setPadding(dp(12), dp(14), dp(12), dp(10));
        scroll.addView(items);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("iOS 18 • Sozlamalar")
                .setView(scroll)
                .setNegativeButton("Yopish", null).create();
        addSetting(items, "★  Standart bosh ekran", isDefaultHome() ?
                "Standart launcher tanlangan" : "Telefon tizimidan HOME ruxsatini tanlang", () -> {
            dialog.dismiss(); requestDefaultHome();
        });
        addSetting(items, "▧  Galereyadan fon rasmi", "O‘zingiz xohlagan JPG/PNG rasmni tanlang", () -> {
            dialog.dismiss(); chooseWallpaper();
        });
        addSetting(items, "◉  Qora mavzular", "AMOLED 18, Obsidian, Carbon, Noir, Midnight, Graphite", () -> {
            dialog.dismiss(); showThemes();
        });
        addSetting(items, "☾  Telefon Dark Mode", "Dark Mode qo‘llovchi boshqa ilovalarni ham qoraytirish uchun", () -> {
            dialog.dismiss();
            try { startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Displey sozlamalarini telefon sozlamasidan oching", Toast.LENGTH_LONG).show(); }
        });
        addSetting(items, "◐  Oq monoxrom ikonlar", monochrome() ?
                "Hozir: yoqilgan (o‘chirish)" : "Hozir: rangli (oq ikonlarga o‘tish)", () -> {
            preferences.edit().putBoolean("mono_icons", !monochrome()).apply();
            dialog.dismiss(); render();
        });
        addSetting(items, "≡  Ilova nomlari", showLabels() ?
                "Hozir: ko‘rsatiladi" : "Hozir: yashirilgan", () -> {
            preferences.edit().putBoolean("show_labels", !showLabels()).apply();
            dialog.dismiss(); render();
        });
        addSetting(items, "▦  Ikonlar soni", "Hozir: " + drawerColumns() + " ta ustun (4 yoki 5)", () -> {
            preferences.edit().putInt("drawer_columns", drawerColumns() == 4 ? 5 : 4).apply();
            dialog.dismiss(); render();
        });
        addSetting(items, "◫  Yashirilgan ilovalar", "Yashirilgan ilovalarni vaqtincha ko‘rsatish", () -> {
            showHidden = !showHidden;
            dialog.dismiss();
            render(); openDrawer();
            Toast.makeText(this, showHidden ? "Yashirilgan ilovalar ko‘rinmoqda" :
                    "Yashirilgan ilovalar berkitildi", Toast.LENGTH_SHORT).show();
        });
        addSetting(items, "▧  Telefon foniga ham o‘rnatish", "Tanlangan rasmni Android bosh foniga qo‘yish", () -> {
            dialog.dismiss(); applySystemWallpaper();
        });
        addSetting(items, "↺  Qora fonni tiklash", "Galereyadan tanlangan launcher fonini o‘chirish", () -> {
            dialog.dismiss(); removeWallpaper();
        });
        addSetting(items, "✓  Ruxsatlar", "HOME ruxsati va rasm tanlash haqida", () -> {
            dialog.dismiss(); showPermissionInfo();
        });
        dialog.show();
        // Android gives the scroll view the available dialog height automatically.
    }

    private void showPermissionInfo() {
        new AlertDialog.Builder(this).setTitle("Ruxsatlar")
                .setMessage("1. Standart bosh ekran: telefon sozlamasidan HOME ruxsatini tanlaysiz. " +
                        "Bu launcherga qaytib turish uchun kerak.\n\n" +
                        "2. Galereya: faqat siz tanlagan rasmni ochadi; barcha fotolarga " +
                        "keng ruxsat so‘ralmaydi.\n\n" +
                        "3. Telefon fonini o‘zgartirish: SET_WALLPAPER tizim ruxsati " +
                        "manifestda ko‘rsatilgan. Alohida popup chiqmasligi odatiy.\n\n" +
                        "Internet, SMS, kontaktlar va ekran ustida ko‘rsatish ruxsatlari kerak emas. Reklama SDK yo‘q.")
                .setPositiveButton("HOME ni tanlash", (d, w) -> requestDefaultHome())
                .setNeutralButton("Rasm tanlash", (d, w) -> chooseWallpaper())
                .setNegativeButton("Yopish", null).show();
    }

    private void updateClock() {
        if (clockView == null || dateView == null) return;
        Date now = new Date();
        clockView.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now));
        dateView.setText(DateFormat.getDateInstance(DateFormat.FULL, Locale.getDefault()).format(now));
    }
}
