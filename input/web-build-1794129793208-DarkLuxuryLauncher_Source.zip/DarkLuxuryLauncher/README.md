# DARK LUXURY Launcher v1.0

Original lightweight Android home launcher project, black & gold UI, English only, no ads.

## Build an APK
1. Install Android Studio (with Android SDK Platform 35).
2. Open the `DarkLuxuryLauncher` folder as a project.
3. Let Gradle sync (requires internet for the Android Gradle Plugin).
4. Select **Build > Build APK(s)**.
5. Find `app/build/outputs/apk/debug/app-debug.apk`.
6. Install the APK, open DARK LUXURY, choose **SET DEFAULT HOME**.

## Features
- Real HOME intent and Android 10 Home role request
- Launcher app grid, search, basic category folders
- Black/gold style, large draggable clock, swipe-up app drawer
- Android's own notification/usage settings access (optional)
- Android document picker to change system wallpaper
- Android settings access for app cache management

## Important limitations
- This ZIP is **source code**, not a precompiled APK. Building requires Android Studio/Android SDK.
- Smart folders use rule-based automatic categorization; not all apps can be classified perfectly.
- Android does not allow third-party launchers to wipe every other app's cache silently.
- Notification permission settings link does not implement live notification badges.
- This first version is a functional foundation, not a full theme marketplace or icon-pack engine.
- Android 13+ may display standard user prompts/behavior for notifications; no sensitive permissions requested silently.
