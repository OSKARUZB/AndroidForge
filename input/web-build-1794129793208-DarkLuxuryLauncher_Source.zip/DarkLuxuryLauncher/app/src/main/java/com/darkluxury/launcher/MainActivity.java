package com.darkluxury.launcher;

import android.app.Activity;
import android.app.role.RoleManager;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int GOLD = Color.rgb(220, 184, 105);
    private static final int MUTED = Color.rgb(154, 150, 145);
    private static final int BG = Color.rgb(8, 9, 11);
    private static final int PANEL = Color.rgb(23, 24, 27);
    private static final int PICK_WALLPAPER = 210;
    private FrameLayout root;
    private LinearLayout surface;
    private TextView clock, subtitle;
    private boolean drawerVisible = false;
    private float downY;
    private final Handler handler = new Handler();
    private final Runnable tick = new Runnable() { @Override public void run() { updateClock(); handler.postDelayed(this, 1000); } };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildHome();
        handler.post(tick);
        if (!getPreferences(0).getBoolean("welcomed", false)) {
            getPreferences(0).edit().putBoolean("welcomed", true).apply();
            new Handler().postDelayed(this::showWelcome, 450);
        }
    }
    @Override protected void onDestroy() { handler.removeCallbacks(tick); super.onDestroy(); }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private GradientDrawable bg(int color, int radius, boolean border) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (border) d.setStroke(dp(1), Color.rgb(82, 67, 41)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(size);
        t.setFontFeatureSettings("kern"); if(bold)t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView action(String label, Runnable click) {
        TextView v = text(label, 14, GOLD, true); v.setGravity(Gravity.CENTER); v.setPadding(dp(16),dp(13),dp(16),dp(13));
        v.setBackground(bg(PANEL, 16, true)); v.setOnClickListener(x->click.run()); return v;
    }
    private void buildHome() {
        drawerVisible = false;
        root = new FrameLayout(this); root.setBackgroundColor(BG); setContentView(root);
        surface = column(); surface.setPadding(dp(21),dp(24),dp(21),dp(18));
        root.addView(surface, new FrameLayout.LayoutParams(-1,-1));
        TextView brand = text("D A R K   L U X U R Y", 12, GOLD, true);
        brand.setGravity(Gravity.CENTER); surface.addView(brand);
        FrameLayout hero = new FrameLayout(this);
        surface.addView(hero, new LinearLayout.LayoutParams(-1, 0, 1));
        clock = text("", 63, Color.WHITE, false); clock.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER); hero.addView(clock, cp);
        subtitle = text("", 12, MUTED, false); subtitle.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER); sp.topMargin=dp(104); hero.addView(subtitle,sp);
        final float[] touch = {0,0};
        clock.setOnTouchListener((v,e)->{
            switch(e.getAction()){
                case MotionEvent.ACTION_DOWN: touch[0]=e.getRawX();touch[1]=e.getRawY();return true;
                case MotionEvent.ACTION_MOVE:
                    v.setTranslationX(Math.max(-dp(110),Math.min(dp(110),v.getTranslationX()+e.getRawX()-touch[0])));
                    v.setTranslationY(Math.max(-dp(180),Math.min(dp(180),v.getTranslationY()+e.getRawY()-touch[1])));
                    touch[0]=e.getRawX();touch[1]=e.getRawY();return true;
                case MotionEvent.ACTION_UP: return true;
            } return false;
        });
        TextView hint = text("SWIPE UP  ·  ALL APPS", 10, MUTED, true); hint.setGravity(Gravity.CENTER);hint.setPadding(0,dp(12),0,dp(18));surface.addView(hint);
        LinearLayout dock = new LinearLayout(this); dock.setGravity(Gravity.CENTER); dock.setPadding(dp(4),dp(12),dp(4),dp(12));dock.setBackground(bg(PANEL,22,true)); surface.addView(dock);
        addDock(dock,"APPS",this::showDrawer);addDock(dock,"FOLDERS",this::showFolders);addDock(dock,"SETTINGS",this::showSettings);
        root.setOnTouchListener((v,e)->{ if(e.getAction()==MotionEvent.ACTION_DOWN){downY=e.getY();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){if(downY-e.getY()>dp(55)){showDrawer();return true;}return true;}return true;});
        updateClock();
    }
    private void addDock(LinearLayout l,String title,Runnable run){
        TextView b=text(title,11,GOLD,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(7),dp(10),dp(7),dp(10));
        l.addView(b,new LinearLayout.LayoutParams(0,-2,1)); b.setOnClickListener(v->run.run());
    }
    private void updateClock(){if(clock!=null){clock.setText(new SimpleDateFormat("HH:mm",Locale.ENGLISH).format(new Date()));}
        if(subtitle!=null)subtitle.setText(new SimpleDateFormat("EEEE  ·  dd MMMM yyyy",Locale.ENGLISH).format(new Date()).toUpperCase(Locale.ENGLISH));}
    private void newPage(String heading){
        root=new FrameLayout(this);root.setBackgroundColor(BG);setContentView(root);
        LinearLayout vertical=column();vertical.setPadding(dp(17),dp(16),dp(17),0);root.addView(vertical,new FrameLayout.LayoutParams(-1,-1));
        TextView top=action("‹   " + heading, this::buildHome);top.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);vertical.addView(top);
        surface=vertical;
    }
    private List<ResolveInfo> apps(){
        Intent i=new Intent(Intent.ACTION_MAIN,null);i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found=getPackageManager().queryIntentActivities(i,0);
        found.sort((a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        return found;
    }
    private void showDrawer(){
        newPage("ALL APPS");drawerVisible=true;
        EditText search=new EditText(this);search.setSingleLine(true); search.setHint("Search apps...");search.setHintTextColor(MUTED);
        search.setTextColor(Color.WHITE);search.setTextSize(15);search.setPadding(dp(15),dp(12),dp(15),dp(12));search.setBackground(bg(PANEL,15,true));
        LinearLayout.LayoutParams se=new LinearLayout.LayoutParams(-1,-2);se.setMargins(0,dp(16),0,dp(10));surface.addView(search,se);
        ScrollView scroll=new ScrollView(this);surface.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        GridLayout grid=new GridLayout(this);grid.setColumnCount(4);grid.setPadding(0,dp(7),0,dp(18));scroll.addView(grid);
        List<ResolveInfo> all=apps();renderApps(grid,all);
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){List<ResolveInfo> filtered=new ArrayList<>();
                for(ResolveInfo r:all)if(r.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT).contains(s.toString().toLowerCase(Locale.ROOT)))filtered.add(r);
                renderApps(grid,filtered);}
            public void afterTextChanged(android.text.Editable e){} });
    }
    private void renderApps(GridLayout grid,List<ResolveInfo> all){
        grid.removeAllViews();int width=getResources().getDisplayMetrics().widthPixels-dp(34);
        int cell=width/4;
        for(ResolveInfo app:all){
            LinearLayout item=column();item.setGravity(Gravity.CENTER); item.setPadding(dp(3),dp(12),dp(3),dp(12));
            ImageView icon=new ImageView(this);
            try{Drawable d=app.loadIcon(getPackageManager());icon.setImageDrawable(d);}catch(Exception ignored){}
            item.addView(icon,new LinearLayout.LayoutParams(dp(47),dp(47)));
            TextView title=text(app.loadLabel(getPackageManager()).toString(),10,Color.LTGRAY,false);
            title.setGravity(Gravity.CENTER);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(34));tp.topMargin=dp(7);item.addView(title,tp);
            grid.addView(item,new ViewGroup.LayoutParams(cell,dp(111)));
            item.setOnClickListener(v->{try{Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(Intent.CATEGORY_LAUNCHER);
                intent.setComponent(new ComponentName(app.activityInfo.packageName,app.activityInfo.name));intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(intent);
                }catch(Exception ex){Toast.makeText(this,"Unable to open this app",Toast.LENGTH_SHORT).show();}});
        }
    }
    private void showFolders(){
        newPage("SMART FOLDERS");
        String[] names={"GAMES","GOOGLE","SOCIAL","TOOLS","OTHER"};
        for(String n:names){TextView t=action("◈   "+n+"   ›",()->showFolder(n));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(14),0,0);surface.addView(t,p);}
    }
    private String groupFor(ResolveInfo r){
        String pkg=r.activityInfo.packageName.toLowerCase(Locale.ROOT);
        String label=r.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);
        if ((r.activityInfo.applicationInfo.category==android.content.pm.ApplicationInfo.CATEGORY_GAME)||pkg.contains("game")||label.contains("game"))return "GAMES";
        if(pkg.startsWith("com.google.")||pkg.startsWith("com.android.chrome"))return "GOOGLE";
        if(pkg.contains("instagram")||pkg.contains("whatsapp")||pkg.contains("telegram")||pkg.contains("facebook")||pkg.contains("tiktok")||pkg.contains("discord"))return "SOCIAL";
        if(label.contains("settings")||label.contains("file")||label.contains("clock")||label.contains("calculator")||label.contains("camera"))return "TOOLS";
        return "OTHER";
    }
    private void showFolder(String name){newPage(name);ScrollView sv=new ScrollView(this);surface.addView(sv);
        GridLayout g=new GridLayout(this);g.setColumnCount(4);sv.addView(g);List<ResolveInfo> selected=new ArrayList<>();for(ResolveInfo r:apps())if(groupFor(r).equals(name))selected.add(r);renderApps(g,selected);}
    private void showSettings(){
        newPage("SETTINGS");
        ScrollView sc=new ScrollView(this);surface.addView(sc);LinearLayout list=column();list.setPadding(0,dp(8),0,dp(30));sc.addView(list);
        addSetting(list,"SET AS DEFAULT HOME",this::requestHomeRole,"Show Android's Home app selection dialog");
        addSetting(list,"NOTIFICATION ACCESS",()->openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS),"Optional: manage notification access in Android settings");
        addSetting(list,"USAGE ACCESS",()->openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS),"Optional: app usage access in Android settings");
        addSetting(list,"CHANGE WALLPAPER",this::pickWallpaper,"Choose a picture with Android photo picker");
        addSetting(list,"STORAGE & CACHE",()->openSettings(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS),"Android handles other apps' cache; no fake one-tap cleaning");
        addSetting(list,"ALL APPS",this::showDrawer,"Find installed apps by name");
        addSetting(list,"ABOUT",()->new android.app.AlertDialog.Builder(this).setTitle("DARK LUXURY 1.0").setMessage("Black & Gold • English • Ad-free\nAndroid 8+ • Designed for Android 10").setPositiveButton("OK",null).show(),"Original lightweight launcher");
    }
    private void addSetting(LinearLayout l,String heading,Runnable run,String detail){
        LinearLayout block=column();block.setPadding(dp(14),dp(14),dp(14),dp(14));block.setBackground(bg(PANEL,16,true));
        TextView name=text(heading,13,GOLD,true);block.addView(name);TextView d=text(detail,12,MUTED,false);d.setPadding(0,dp(6),0,0);block.addView(d);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(11),0,0);l.addView(block,p);block.setOnClickListener(v->run.run());
    }
    private void showWelcome(){new android.app.AlertDialog.Builder(this).setTitle("Welcome to DARK LUXURY")
        .setMessage("Choose DARK LUXURY as your Home app to make it your default launcher. Optional access can be enabled later in Settings. All permission changes use official Android screens.")
        .setPositiveButton("SET DEFAULT HOME",(d,w)->requestHomeRole())
        .setNegativeButton("LATER",(d,w)->{}).show();}
    private void requestHomeRole(){
        if(Build.VERSION.SDK_INT>=29){RoleManager roles=(RoleManager)getSystemService(ROLE_SERVICE);
            if(roles!=null&&roles.isRoleAvailable(RoleManager.ROLE_HOME)){
                if(roles.isRoleHeld(RoleManager.ROLE_HOME)){Toast.makeText(this,"Already the default Home app",Toast.LENGTH_SHORT).show();return;}
                startActivityForResult(roles.createRequestRoleIntent(RoleManager.ROLE_HOME),125);return;}}
        openSettings(Settings.ACTION_HOME_SETTINGS);
    }
    private void openSettings(String action){try{startActivity(new Intent(action));}catch(ActivityNotFoundException e){Toast.makeText(this,"Settings screen unavailable",Toast.LENGTH_SHORT).show();}}
    private void pickWallpaper(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(i,PICK_WALLPAPER);}catch(Exception e){Toast.makeText(this,"Photo picker unavailable",Toast.LENGTH_SHORT).show();}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==PICK_WALLPAPER&&result==RESULT_OK&&data!=null&&data.getData()!=null){
            try{WallpaperManager.getInstance(this).setStream(getContentResolver().openInputStream(data.getData()));
                Toast.makeText(this,"Wallpaper changed",Toast.LENGTH_SHORT).show();}
            catch(Exception e){Toast.makeText(this,"Could not change wallpaper",Toast.LENGTH_LONG).show();}}
    }
    @Override public void onBackPressed(){if(drawerVisible || surface!=null){buildHome();}else{super.onBackPressed();}}
}
