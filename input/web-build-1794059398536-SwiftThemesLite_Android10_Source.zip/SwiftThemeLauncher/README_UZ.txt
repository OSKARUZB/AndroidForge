SWIFT THEMES LITE — ANDROID UCHUN YENGIL LAUNCHER
===================================================

BU ARXIV NIMA?
Ushbu arxiv tayyor APK emas, balki ishlaydigan launcher APK dasturining
Android Studio loyihasi (Java manba kodlari va resurslar) hisoblanadi.

IMKONIYATLAR:
- 6 ta mavzu: Midnight, Ocean, Graphite, Emerald, Sunset, Light
- Oddiy va tezkor bosh ekran (HOME launcher)
- Soat va sana
- Telefoningizda o'rnatilgan ilovalar ro'yxati
- Ilovalarni nomi bilan qidirish
- Ilova belgisini uzoq bosish orqali dockga qo'shish / chiqarish
- 4 ta sevimli ilova uchun dock
- Internet, obuna, reklama, fon servis va uchinchi tomon kutubxonalari yo'q
- Android 6.0+ ishlashi uchun kod yozilgan, Android 10 uchun mo'ljallangan

APK YIG'ISH (ENG OSON USUL):
1. Windows kompyuterga Android Studio o'rnating (developer.android.com/studio).
2. Android Studio > SDK Manager > Android API 35 (SDK Platform) o'rnating.
3. Arxivni ZIPdan chiqaring.
4. Android Studio > Open > SwiftThemeLauncher papkasini tanlang.
5. Gradle Sync tugaguncha Android Studio'ning build oynasidagi jarayonni kuzating.
6. Build > Build Bundle(s) / APK(s) > Build APK(s) ni tanlang.
7. Tayyor fayl: app/build/outputs/apk/debug/app-debug.apk

WINDOWS UCHUN QO'SHIMCHA USUL:
Android Studio va Android SDK o'rnatilgan bo'lsa, BUILD_APK_WINDOWS.bat ni
ishga tushiring. Birinchi marta internet orqali Gradle yuklaydi.
Android SDK 35 va Java 17 talab etiladi.

TELEFONGA O'RNATISH:
1. app-debug.apk faylini telefoningizga ko'chiring.
2. O'rnatishga ruxsat bergan holda faylni oching va o'rnating.
3. Sozlamalar > Ilovalar > Standart ilovalar > Bosh ekran (Home app)
   bo'limidan 'Swift Themes Lite' ni tanlang.
   (Bo'lim nomlari Android ishlab chiqaruvchisiga qarab farq qiladi.)
4. Asosiy ekran yuqorisidagi 'Mavzular' tugmasi bilan mavzuni o'zgartiring.
5. 'Barcha ilovalar'ni oching. Ilovani uzoq bosib dockga biriktiring.
6. Eski launcherga qaytish uchun Standart ilovalar > Bosh ekran bo'limida
   avvalgi launcherni tanlang.

SAMARADORLIK VA XAVFSIZLIK:
Dastur maxsus servislar va tarmoq ruxsatlarisiz ishlaydi.
Bu telefon xotirasi, boshqa ilovalar yoki o'yin FPSini oshirmaydi.
Telefon va boshqa ilovalar ishlashiga qarab unumdorlik farq qiladi.

TEXNIK:
Java, Android SDK; minSdk 23; targetSdk 29; compileSdk 35;
Android Gradle Plugin 8.7.3; Gradle 8.9; JDK 17.

Ushbu APK talabga muvofiq shaxsiy o'rnatish uchun mo'ljallangan;
Play Storega chiqarish uchun yangi target SDK va qo'shimcha tekshiruvlar kerak.
