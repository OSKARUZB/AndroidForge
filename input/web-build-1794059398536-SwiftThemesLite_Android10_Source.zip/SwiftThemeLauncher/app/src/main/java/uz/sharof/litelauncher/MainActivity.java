package uz.sharof.litelauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Lightweight, single-activity Android home launcher.
 * No background services, network, analytics, 3D effects or third-party libraries.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "swift_themes_lite";
    private static final String THEME_KEY = "theme";
    private static final String FAVORITES_KEY = "favorite_components";

    private static final String[] NAMES = {
        "Midnight", "Ocean", "Graphite", "Emerald", "Sunset", "Light"
    };
    private static final int[][] PALETTE = {
        {0xFF151A31, 0xFF070A14, 0xFFB4A0FF, 0xFFF5F7FF, 0xFF232B47},
        {0xFF09375A, 0xFF041222, 0xFF66D8FF, 0xFFF5FAFF, 0xFF143C58},
        {0xFF252934, 0xFF0A0C12, 0xFFB8F36D, 0xFFF9FAFC, 0xFF313746},
        {0xFF145444, 0xFF041F20, 0xFF65F4BC, 0xFFF5FFFA, 0xFF225E52},
        {0xFF663A53, 0xFF231428, 0xFFFFC197, 0xFFFFF9F9, 0xFF744C67},
        {0xFFF4F7FD, 0xFFDCE6F2, 0xFF4F46E5, 0xFF16233A, 0xFFFFFFFF}
    };
    private static final int FROM = 0, TO = 1, ACCENT = 2, TEXT = 3, SURFACE = 4;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<AppItem> apps = new ArrayList<>();
    private SharedPreferences prefs;
    private FrameLayout root;
    private View drawer;
    private TextView timeView;
    private TextView dateView;
    private boolean showingDrawer = false;
    private int activeTheme;
    private long lastAppRefresh;

    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 30_000);
        }
    };

    static class AppItem {
        String label;
        String pkg;
        String cls;
        Drawable icon;
        String id() { return pkg + "/" + cls; }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        activeTheme = clamp(prefs.getInt(THEME_KEY, 0), 0, NAMES.length - 1);
        loadApps();
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(clockTick);
        handler.post(clockTick);
        if (System.currentTimeMillis() - lastAppRefresh > 60_000) {
            loadApps();
            if (!showingDrawer) render();
        }
    }

    @Override protected void onPause() {
        handler.removeCallbacks(clockTick);
        super.onPause();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        render();
    }

    @Override public void onBackPressed() {
        if (showingDrawer) {
            hideDrawer();
        } else {
            // Home launcher is deliberately kept in the foreground.
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (showingDrawer) hideDrawer();
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private int dp(float dp) {
        return (int)(getResources().getDisplayMetrics().density * dp + 0.5f);
    }

    private int c(int index) {
        return PALETTE[activeTheme][index];
    }

    private int whiteWithAlpha(int alpha) {
        return Color.argb(alpha, activeTheme == 5 ? 18 : 255,
                activeTheme == 5 ? 25 : 255,
                activeTheme == 5 ? 50 : 255);
    }

    private GradientDrawable rounded(int fill, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private TextView label(String value, float size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        text.setTextColor(color);
        text.setIncludeFontPadding(false);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return text;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(query, 0);
        ArrayList<AppItem> loaded = new ArrayList<>();
        HashSet<String> known = new HashSet<>();
        for (ResolveInfo info : found) {
            if (info.activityInfo == null) continue;
            if (getPackageName().equals(info.activityInfo.packageName)) continue;
            AppItem item = new AppItem();
            item.pkg = info.activityInfo.packageName;
            item.cls = info.activityInfo.name;
            if (!known.add(item.id())) continue;
            CharSequence appName = info.loadLabel(pm);
            item.label = appName == null ? item.pkg : appName.toString();
            try { item.icon = info.loadIcon(pm); } catch (Exception ignored) { }
            loaded.add(item);
        }
        Collections.sort(loaded, new Comparator<AppItem>() {
            @Override public int compare(AppItem a, AppItem b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        apps.clear();
        apps.addAll(loaded);
        lastAppRefresh = System.currentTimeMillis();
    }

    private void render() {
        showingDrawer = false;
        drawer = null;
        Window w = getWindow();
        w.setStatusBarColor(c(FROM));
        w.setNavigationBarColor(c(TO));
        if (activeTheme == 5) {
            w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        } else {
            w.getDecorView().setSystemUiVisibility(0);
        }
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        root = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{c(FROM), c(TO)});
        root.setBackground(bg);
        setContentView(root);

        LinearLayout home = vertical();
        home.setPadding(dp(22), dp(24), dp(22), dp(18));
        root.addView(home, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        home.addView(topRow, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView brand = label("SWIFT  /  THEMES LITE", 12, c(TEXT), true);
        brand.setLetterSpacing(0.1f);
        topRow.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        TextView themeButton = label("◉   Mavzular", 13, c(TEXT), true);
        themeButton.setGravity(Gravity.CENTER);
        themeButton.setPadding(dp(15), dp(10), dp(15), dp(10));
        themeButton.setBackground(rounded(c(SURFACE), 22));
        themeButton.setOnClickListener(v -> showThemes());
        topRow.addView(themeButton);

        View gap = new View(this);
        home.addView(gap, new LinearLayout.LayoutParams(1, dp(60)));

        timeView = label("", 69, c(TEXT), true);
        timeView.setLetterSpacing(-0.05f);
        home.addView(timeView);
        dateView = label("", 16, whiteWithAlpha(210), false);
        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(-1, -2);
        dateParams.topMargin = dp(3);
        home.addView(dateView, dateParams);
        updateClock();

        View spacer = new View(this);
        home.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));

        TextView line = label("TEZ • SODDA • CHIROYLI", 11, whiteWithAlpha(175), true);
        line.setGravity(Gravity.CENTER);
        line.setLetterSpacing(0.18f);
        LinearLayout.LayoutParams lineP = new LinearLayout.LayoutParams(-1, dp(25));
        lineP.bottomMargin = dp(14);
        home.addView(line, lineP);

        LinearLayout dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setPadding(dp(7), dp(12), dp(7), dp(12));
        dock.setBackground(rounded(c(SURFACE), 24));
        LinearLayout.LayoutParams dockParams = new LinearLayout.LayoutParams(-1, dp(108));
        dockParams.bottomMargin = dp(15);
        home.addView(dock, dockParams);
        List<AppItem> pinned = chosenDock();
        for (int i = 0; i < 4; i++) {
            if (i < pinned.size()) {
                dock.addView(appButton(pinned.get(i), true, dp(75)),
                        new LinearLayout.LayoutParams(0, -1, 1));
            } else {
                TextView empty = label("+", 22, c(ACCENT), true);
                empty.setGravity(Gravity.CENTER);
                empty.setOnClickListener(v -> showDrawer());
                dock.addView(empty, new LinearLayout.LayoutParams(0, -1, 1));
            }
        }

        TextView openApps = label("⌕    Barcha ilovalar", 16, c(TEXT), true);
        openApps.setGravity(Gravity.CENTER);
        openApps.setBackground(rounded(c(SURFACE), 20));
        openApps.setOnClickListener(v -> showDrawer());
        home.addView(openApps, new LinearLayout.LayoutParams(-1, dp(57)));
    }

    private List<AppItem> chosenDock() {
        ArrayList<AppItem> selected = new ArrayList<>();
        Set<String> favorites = prefs.getStringSet(FAVORITES_KEY, Collections.emptySet());
        for (AppItem app : apps) {
            if (favorites.contains(app.id())) selected.add(app);
            if (selected.size() == 4) return selected;
        }
        String[] common = {"com.whatsapp", "org.telegram.messenger", "com.android.chrome",
                "com.google.android.dialer", "com.android.dialer",
                "com.google.android.googlequicksearchbox", "com.android.camera"};
        for (String pkg : common) {
            for (AppItem app : apps) {
                if (app.pkg.equals(pkg) && !selected.contains(app)) selected.add(app);
                if (selected.size() == 4) return selected;
            }
        }
        for (AppItem app : apps) {
            if (!selected.contains(app)) selected.add(app);
            if (selected.size() == 4) break;
        }
        return selected;
    }

    private View appButton(AppItem item, boolean dock, int cellWidth) {
        LinearLayout cell = vertical();
        cell.setGravity(Gravity.CENTER);
        cell.setMinimumWidth(cellWidth);
        cell.setPadding(dp(2), dp(6), dp(2), dp(4));
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (item.icon != null) image.setImageDrawable(item.icon);
        else {
            image.setBackground(rounded(c(ACCENT), 15));
        }
        cell.addView(image, new LinearLayout.LayoutParams(dp(dock ? 48 : 45), dp(dock ? 48 : 45)));
        TextView title = label(item.label, dock ? 11 : 11, c(TEXT), false);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleP = new LinearLayout.LayoutParams(-1, dp(25));
        titleP.topMargin = dp(5);
        cell.addView(title, titleP);
        cell.setOnClickListener(v -> launchApp(item));
        cell.setOnLongClickListener(v -> {
            toggleFavorite(item);
            return true;
        });
        return cell;
    }

    private void launchApp(AppItem app) {
        try {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            intent.setComponent(new ComponentName(app.pkg, app.cls));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Ilova ochilmadi", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFavorite(AppItem item) {
        Set<String> existing = prefs.getStringSet(FAVORITES_KEY, Collections.emptySet());
        HashSet<String> copy = new HashSet<>(existing);
        boolean added;
        if (copy.contains(item.id())) { copy.remove(item.id()); added = false; }
        else if (copy.size() >= 4) {
            Toast.makeText(this, "Dockda eng ko‘pi 4 ta ilova bo‘ladi", Toast.LENGTH_SHORT).show();
            return;
        } else { copy.add(item.id()); added = true; }
        prefs.edit().putStringSet(FAVORITES_KEY, copy).apply();
        Toast.makeText(this, (added ? "Dockga qo‘shildi: " : "Dockdan olib tashlandi: ")
                + item.label, Toast.LENGTH_SHORT).show();
        if (!showingDrawer) render();
    }

    private void showDrawer() {
        if (showingDrawer) return;
        showingDrawer = true;
        LinearLayout panel = vertical();
        panel.setPadding(dp(18), dp(20), dp(18), dp(7));
        panel.setBackground(rounded(c(SURFACE), 26));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, -1);
        pp.topMargin = dp(70);
        pp.leftMargin = dp(8);
        pp.rightMargin = dp(8);
        root.addView(panel, pp);
        drawer = panel;

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        panel.addView(header, new LinearLayout.LayoutParams(-1, dp(40)));

        TextView back = label("‹", 34, c(ACCENT), true);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> hideDrawer());
        header.addView(back, new LinearLayout.LayoutParams(dp(45), -1));

        TextView title = label("Barcha ilovalar", 21, c(TEXT), true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        TextView refresh = label("↻", 26, c(ACCENT), true);
        refresh.setGravity(Gravity.CENTER);
        refresh.setOnClickListener(v -> { loadApps(); hideDrawer(); showDrawer(); });
        header.addView(refresh, new LinearLayout.LayoutParams(dp(46), -1));

        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(c(TEXT));
        search.setHintTextColor(whiteWithAlpha(155));
        search.setHint("Ilova qidirish...");
        search.setTextSize(15);
        search.setPadding(dp(16), 0, dp(16), 0);
        search.setBackground(rounded(c(FROM), 15));
        LinearLayout.LayoutParams searchP = new LinearLayout.LayoutParams(-1, dp(52));
        searchP.topMargin = dp(14);
        searchP.bottomMargin = dp(12);
        panel.addView(search, searchP);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setPadding(0, dp(4), 0, dp(20));
        scroll.addView(grid);
        fillGrid(grid, "");

        TextView hint = label("Bosib turing — dockga qo‘shish yoki olib tashlash",
                12, whiteWithAlpha(205), false);
        hint.setGravity(Gravity.CENTER);
        panel.addView(hint, new LinearLayout.LayoutParams(-1, dp(47)));

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) {
                fillGrid(grid, s.toString());
                scroll.scrollTo(0, 0);
            }
            @Override public void afterTextChanged(Editable editable) { }
        });
    }

    private void fillGrid(GridLayout grid, String filter) {
        grid.removeAllViews();
        String wanted = filter.trim().toLowerCase(Locale.getDefault());
        int screen = getResources().getDisplayMetrics().widthPixels;
        int cellWidth = Math.max(dp(60), (screen - dp(64)) / 4);
        int n = 0;
        for (AppItem app : apps) {
            if (!app.label.toLowerCase(Locale.getDefault()).contains(wanted)) continue;
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = cellWidth;
            params.height = dp(99);
            params.rowSpec = GridLayout.spec(n / 4);
            params.columnSpec = GridLayout.spec(n % 4);
            grid.addView(appButton(app, false, cellWidth), params);
            n++;
        }
        if (n == 0) {
            TextView noApps = label("Ilova topilmadi", 15, c(TEXT), false);
            noApps.setGravity(Gravity.CENTER);
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = screen - dp(64);
            params.height = dp(100);
            params.rowSpec = GridLayout.spec(0);
            params.columnSpec = GridLayout.spec(0, 4);
            grid.addView(noApps, params);
        }
    }

    private void hideDrawer() {
        if (drawer != null) {
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(drawer.getWindowToken(), 0);
            root.removeView(drawer);
            drawer = null;
        }
        showingDrawer = false;
        render(); // refresh favorites after editing
    }

    private void showThemes() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Mavzuni tanlang")
                .setSingleChoiceItems(NAMES, activeTheme, (d, selected) -> {
                    activeTheme = selected;
                    prefs.edit().putInt(THEME_KEY, selected).apply();
                    d.dismiss();
                    render();
                })
                .setNegativeButton("Yopish", null)
                .create();
        dialog.show();
    }

    private void updateClock() {
        if (timeView == null || dateView == null) return;
        Date now = new Date();
        SimpleDateFormat hour = new SimpleDateFormat("HH:mm", Locale.getDefault());
        DateFormat date = DateFormat.getDateInstance(DateFormat.FULL, Locale.getDefault());
        timeView.setText(hour.format(now));
        dateView.setText(date.format(now));
    }
}
