SWIFT THEMES BLACK PRO 2.0 — ANDROID 10, 4 GB RAM UCHUN
======================================================

BU ZIP — MANBA KOD. O'RNATILADIGAN APK EMAS.
ZIP formatini "APK" deb o'zgartirish yoki MConverter bilan aylantirish ishlamaydi.

YANGI FUNKSIYALAR
- Qora AMOLED dizayn, qora ilovalar menyusi va qora ikonka plitkalari.
- 6 xil qora mavzu: AMOLED Black, Violet, Ocean, Neon, Rose, Graphite.
- Boshqa ilovalardagi Dark Mode uchun telefon Displey sozlamasiga o‘tish.
- Rangli yoki oq monoxrom ilova ikonlari (Sozlamalardan).
- Galereyadan JPG/PNG tanlab launcher foniga qo'yish.
- Tanlangan rasmni Android asosiy foniga ham o'rnatish (ixtiyoriy).
- Android 10 uchun "Standart bosh ekran" (HOME) tanlash tugmasi.
- Barcha ilovalar va qidiruv; 4 yoki 5 ta ustunli grid.
- Dockdagi 4 ta ilova; uzoq bosib joylash / olib tashlash.
- Ilovani yashirish va yashirilgan ilovalarni qayta ko'rsatish.
- Soat, sana, fonda reklamasiz va internetsiz ishlash.
- Ruxsatlar haqida aniq tushuntirish; faqat zarur funksiyalar uchun ruxsat.
- Ekran yuqoriga surilganda yoki "Barcha ilovalar" bosilganda app drawer.
- Barcha sozlamalar o'z-o'zidan saqlanib qoladi.

STANDART LAUNCHER QILISH
1. APKni o'rnating va oching.
2. "Standart launcher qilish uchun bosing" yozuvini bosing.
3. Android ochgan ruxsat oynasida "Swift Themes Black" ni tanlang.
4. Agar oyna ochilmasa: Sozlamalar > Ilovalar > Standart ilovalar > Bosh ekran.
5. Oldingi launcherga qaytish uchun shu bo'limdan avvalgisini tanlang.

RUXSATLAR
- Galereyadan rasmni Android fayl tanlagichi orqali tanlaysiz:
  ommaviy fotolarga kirish ruxsati talab etilmaydi.
- SET_WALLPAPER - Android normal permission, popup chiqmaydi.
- HOME ruxsati foydalanuvchining tizimdagi standart ilovasi tanlovidir.
- Boshqa ilovalar ichidagi mavzu, ikonka va ranglar o'zgarmaydi.
- Telefon ishlab chiqaruvchisining o'z launcher funksiyalari shu launcherda
  aynan takrorlanmasligi mumkin. Qotmasligi kafolatlanmaydi.

APK YIG'ISH (ANDROID STUDIO)
1. ZIPni arxivdan chiqaring.
2. Android Studio > Open > SwiftThemesBlackPro loyihasini tanlang.
3. SDK Manager: Android API 35 SDK Platform o'rnatilgan bo'lsin.
4. Build > Build APK(s) (yoki Build Bundle(s) / APK(s) > Build APK(s)).
5. Fayl: app/build/outputs/apk/debug/app-debug.apk

GITHUB ACTIONS (KOMPYUTERSIZ, BRAUZERDA)
1. GitHub'da yangi repo yarating.
2. ZIP ichidagi SwiftThemesBlackPro papkasining FAYLLARINI (ichki .github
   papkasi bilan) repo asosiy joyiga yuklang; ZIPni oddiy fayl qilib emas.
3. Repo > Actions > Build Swift Themes APK > Run workflow.
4. Natija muvaffaqiyatli bo'lsa, Actions > Run > Artifacts dan
   SwiftThemesBlack-APK ni yuklab, arxivdan app-debug.apk ni chiqaring.
5. Agar GitHub Actions uchun qo'lda yig'ish ishlamasa, Windows Android Studio
   usulidan foydalaning.

ESKI VERSIYA O'RNATILGAN BO'LSA
Application ID o'zgarmagan: uz.sharof.litelauncher. Version 2.0.
Boshqa kompyuter debug kaliti bilan signed bo'lsa "App not installed" chiqishi
mumkin. Unda eski APKni o'chirib yangi versiyani o'rnating (sozlamalar o'chadi).

DIQQAT: Bu dastur kodlari yozilgan, lekin hozirgi muhitda Android SDK yo'q,
shuning uchun haqiqiy APK yaratish, telefon/Android emulyatorda tekshirish
amalga oshirilmadi. Gradle buildda noma'lum xato chiqishi mumkin.
