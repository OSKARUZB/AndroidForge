package com.blackglass.launcher;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private FrameLayout root;
    private LinearLayout screen;
    private SharedPreferences prefs;
    private PackageManager pm;
    private List<ResolveInfo> apps = new ArrayList<>();
    private boolean drawer = false;
    private float downX, downY;
    private static final int PICK_WALLPAPER = 77;
    private final int BG = Color.rgb(5,5,8), MUTED = Color.rgb(162,166,178);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("blackglass", MODE_PRIVATE);
        pm = getPackageManager();
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        scan(); showHome();
    }
    @Override protected void onResume() { super.onResume(); if (pm!=null) { scan(); if(drawer) showDrawer("All Apps"); else showHome(); } }
    private int dp(float value) { return (int)(value*getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int color,int radius,int stroke) {
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));
        if(stroke!=0)g.setStroke(dp(1),stroke);return g;
    }
    private TextView label(String str,int sp, int col, boolean bold) {
        TextView v=new TextView(this);v.setText(str);v.setTextColor(col);v.setTextSize(sp);
        v.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL)); return v;
    }
    private void scan() {
        Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);
        apps=pm.queryIntentActivities(i,0);
        Collections.sort(apps,Comparator.comparing(a->a.loadLabel(pm).toString().toLowerCase(Locale.ROOT)));
    }
    private String name(ResolveInfo a){return a.loadLabel(pm).toString();}
    private String group(ResolveInfo a) {
        String pkg=a.activityInfo.packageName.toLowerCase(Locale.ROOT), n=name(a).toLowerCase(Locale.ROOT);
        if(pkg.contains("google") || pkg.contains("android.chrome") || pkg.contains("youtube") || pkg.contains("gmail") || pkg.contains("maps") || pkg.contains("drive") || pkg.contains("vending")) return "Google";
        if(pkg.contains("game")||pkg.contains("mojang")||pkg.contains("roblox")||pkg.contains("supercell")||pkg.contains("unity")||pkg.contains("activision")||pkg.contains("pubg")||pkg.contains("garena")||pkg.contains("minecraft")||pkg.contains("steam")||n.contains("game") || n.contains("polywar") || n.contains("free fire")) return "Games";
        try { ApplicationInfo info=pm.getApplicationInfo(a.activityInfo.packageName,0); if((info.category==ApplicationInfo.CATEGORY_GAME)) return "Games"; } catch(Exception ignored) {}
        if(pkg.contains("telegram")||pkg.contains("whatsapp")||pkg.contains("instagram")||pkg.contains("tiktok")||pkg.contains("facebook")||pkg.contains("discord")||pkg.contains("snapchat"))return "Social";
        return "Apps";
    }
    private int iconId(String pkg,String n,String grp) {
        String p=pkg.toLowerCase(Locale.ROOT), s=n.toLowerCase(Locale.ROOT);String id=null;
        String[][] known={
            {"telegram","telegram"},{"whatsapp","whatsapp"},{"instagram","instagram"},{"youtube","youtube"},
            {"tiktok","tiktok"},{"facebook","facebook"},{"chrome","chrome"},{"gmail","gmail"},
            {"maps","google_maps"},{"drive","google_drive"},{"vending","play_store"},{"play store","play_store"},
            {"spotify","spotify"},{"netflix","netflix"},{"discord","discord"},{"snapchat","snapchat"},
            {"pinterest","pinterest"},{"chatgpt","chatgpt"},{"camera","camera"},{"gallery","gallery"},
            {"contacts","contacts"},{"dialer","phone"},{"phone","phone"},{"messages","messages"},
            {"settings","settings"},{"clock","clock"},{"calendar","calendar"},{"calculator","calculator"},
            {"files","files"},{"music","music"},{"weather","weather"},{"downloads","downloads"},
            {"recorder","voice_recorder"},{"notes","notes"},{"security","security"},{"flashlight","flashlight"}
        };
        for(String[] k:known) if(p.contains(k[0])||s.equals(k[0])) {id=k[1];break;}
        if(id==null&&"Games".equals(grp))id="games";
        if(id==null&&"Google".equals(grp))id="google";
        return id==null?0:getResources().getIdentifier("glass_"+id,"drawable",getPackageName());
    }
    private void start(ResolveInfo a){
        try { Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setComponent(new ComponentName(a.activityInfo.packageName,a.activityInfo.name));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);
        }catch(Exception e){Toast.makeText(this,"App cannot be opened",Toast.LENGTH_SHORT).show();}
    }
    private ImageView appImage(ResolveInfo a,int size) {
        ImageView iv=new ImageView(this);String grp=group(a);int id=iconId(a.activityInfo.packageName,name(a),grp);
        if(id!=0)iv.setImageResource(id);else iv.setImageDrawable(a.loadIcon(pm));
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);iv.setLayoutParams(new LinearLayout.LayoutParams(dp(size),dp(size)));return iv;
    }
    private View tile(ResolveInfo a,int width) {
        LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setGravity(Gravity.CENTER);
        col.setPadding(dp(3),dp(7),dp(3),dp(8));col.setLayoutParams(new ViewGroup.LayoutParams(dp(width),dp(112)));
        col.addView(appImage(a,61));
        TextView t=label(name(a),11,Color.WHITE,false);t.setGravity(Gravity.CENTER);t.setSingleLine(true);t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(width-6),dp(30));tp.topMargin=dp(4);col.addView(t,tp);
        col.setOnClickListener(v->start(a));col.setOnLongClickListener(v->{appDetails(a.activityInfo.packageName);return true;});return col;
    }
    private void appDetails(String p){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+p)));}catch(Exception e) {}}
    private List<ResolveInfo> filtered(String g) {
        List<ResolveInfo> result=new ArrayList<>();for(ResolveInfo a:apps) if(g.equals("All Apps")||group(a).equals(g))result.add(a);return result;
    }
    private void panel(String title,String subtitle) {
        root.removeAllViews(); root.setBackgroundColor(BG);
        screen=new LinearLayout(this);screen.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(-1,-1);root.addView(screen,fp);
        TextView head=label(title,26,Color.WHITE,true);head.setPadding(dp(24),dp(23),0,dp(4));screen.addView(head);
        TextView sub=label(subtitle,12,MUTED,false);sub.setPadding(dp(24),0,dp(14),dp(16));screen.addView(sub);
    }
    private void showHome() {
        drawer=false;panel("BLACK GLASS","SWIPE UP  •  ALL APPS     |     SWIPE DOWN  •  TOOLS");
        FrameLayout space=new FrameLayout(this);screen.addView(space,new LinearLayout.LayoutParams(-1,0,1));
        TextView clock=label("",48,Color.WHITE,true);clock.setGravity(Gravity.CENTER);clock.setPadding(dp(18),dp(12),dp(18),dp(12));
        clock.setBackground(shape(0x990B0E16,24,0x553F4658));
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(275),dp(125));
        cp.leftMargin=prefs.getInt("clockx",24);cp.topMargin=prefs.getInt("clocky",75);space.addView(clock,cp);
        Runnable tick=new Runnable(){@Override public void run(){ if(clock.getParent()==null)return;
            String time=new SimpleDateFormat("HH:mm",Locale.ENGLISH).format(new Date());
            String date=new SimpleDateFormat("EEE, MMM d",Locale.ENGLISH).format(new Date());clock.setText(time+"\n"+date);
            clock.postDelayed(this,30000); }};tick.run();
        clock.setOnTouchListener(new View.OnTouchListener(){float px,py;int ox,oy;
            @Override public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:px=e.getRawX();py=e.getRawY();FrameLayout.LayoutParams l=(FrameLayout.LayoutParams)v.getLayoutParams();ox=l.leftMargin;oy=l.topMargin;return true;
                case MotionEvent.ACTION_MOVE:FrameLayout.LayoutParams a=(FrameLayout.LayoutParams)v.getLayoutParams();
                    a.leftMargin=Math.max(0,Math.min(space.getWidth()-v.getWidth(),ox+(int)(e.getRawX()-px)));
                    a.topMargin=Math.max(0,Math.min(space.getHeight()-v.getHeight(),oy+(int)(e.getRawY()-py)));
                    v.setLayoutParams(a);return true;
                case MotionEvent.ACTION_UP:FrameLayout.LayoutParams b=(FrameLayout.LayoutParams)v.getLayoutParams();prefs.edit().putInt("clockx",b.leftMargin).putInt("clocky",b.topMargin).apply();return true;
            }return false;}});
        LinearLayout folders=new LinearLayout(this);folders.setGravity(Gravity.CENTER);folders.setPadding(dp(8),0,dp(8),dp(25));screen.addView(folders);
        for(String g:new String[]{"Games","Google","Social","Apps"}){
            LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setGravity(Gravity.CENTER);
            folders.addView(col,new LinearLayout.LayoutParams(0,dp(100),1));
            ImageView icon=new ImageView(this);int drawable=g.equals("Games")?R.drawable.glass_games:g.equals("Google")?R.drawable.glass_google:g.equals("Social")?R.drawable.glass_messages:R.drawable.glass_files;
            icon.setImageResource(drawable);icon.setLayoutParams(new LinearLayout.LayoutParams(dp(64),dp(64)));col.addView(icon);
            TextView txt=label(g,12,Color.WHITE,false);txt.setGravity(Gravity.CENTER);col.addView(txt);
            col.setOnClickListener(v->showDrawer(g));
        }
        TextView hint=label("↑  Swipe up to open the app drawer",12,MUTED,false);hint.setGravity(Gravity.CENTER);hint.setPadding(0,0,0,dp(24));screen.addView(hint);
        installSwipe();
    }
    private void installSwipe(){root.setOnTouchListener((v,e)->{switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:downX=e.getX();downY=e.getY();return true;
        case MotionEvent.ACTION_UP:float dy=e.getY()-downY;if(dy<-dp(70))showDrawer("All Apps");else if(dy>dp(70))showTools();return true;
    }return true;});}
    private void showDrawer(String group){
        drawer=true;panel(group.toUpperCase(Locale.ENGLISH),"LONG PRESS AN APP FOR ITS SETTINGS  •  BACK TO HOME");
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);screen.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout inside=new LinearLayout(this);inside.setOrientation(LinearLayout.VERTICAL);inside.setPadding(dp(8),0,dp(8),dp(20));sc.addView(inside);
        if(group.equals("All Apps")){
            HorizontalScrollView strip=new HorizontalScrollView(this);LinearLayout tabs=new LinearLayout(this);tabs.setPadding(dp(12),dp(8),dp(12),dp(14));strip.addView(tabs);
            for(String g:new String[]{"All Apps","Games","Google","Social","Apps"}){
                TextView tab=label(g,13,Color.WHITE,false);tab.setPadding(dp(15),dp(12),dp(15),dp(12));
                tab.setBackground(shape(0xFF1D202A,20,0xFF303341));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,-2);tp.rightMargin=dp(8);tabs.addView(tab,tp);
                tab.setOnClickListener(v->showDrawer(g));}
            inside.addView(strip);
        }
        List<ResolveInfo> list=filtered(group);int columns=4;
        for(int i=0;i<list.size();i+=columns){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_HORIZONTAL);inside.addView(row);
            int width=(getResources().getDisplayMetrics().widthPixels-dp(20))/columns;
            for(int j=i;j<Math.min(i+columns,list.size());j++){ResolveInfo app=list.get(j);row.addView(tile(app,width));}}
        if(list.isEmpty()){TextView empty=label("No apps in this folder yet",15,MUTED,false);empty.setGravity(Gravity.CENTER);empty.setPadding(0,dp(40),0,0);inside.addView(empty);}
        TextView back=label("⌂   HOME     •     SWIPE RIGHT TO GO BACK",13,Color.WHITE,true);back.setGravity(Gravity.CENTER);back.setPadding(0,dp(18),0,dp(26));screen.addView(back);back.setOnClickListener(v->showHome());
        root.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP && e.getX()-downX>dp(70))showHome();return true;});
    }
    private void tool(String name,String desc,Runnable action){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(17),dp(16),dp(17));
        box.setBackground(shape(0xFF141720,20,0xFF343744));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.setMargins(dp(18),dp(6),dp(18),dp(8));screen.addView(box,bp);
        box.addView(label(name,17,Color.WHITE,true));TextView sub=label(desc,12,MUTED,false);sub.setPadding(0,dp(5),0,0);box.addView(sub);box.setOnClickListener(v->action.run());
    }
    private void showTools(){drawer=false;panel("TOOLS","BLACK GLASS • PERSONALIZE YOUR LAUNCHER");
        tool("Set as default launcher","Choose Black Glass as your Home app",()->{
            try{startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));}catch(Exception e){Toast.makeText(this,"Open Settings → Default apps → Home app",Toast.LENGTH_LONG).show();}});
        tool("Choose wallpaper","Pick a photo from your gallery",()->{
            Intent in=new Intent(Intent.ACTION_GET_CONTENT);in.setType("image/*");startActivityForResult(Intent.createChooser(in,"Choose wallpaper"),PICK_WALLPAPER);});
        tool("Clean cache","Open Android storage settings to free space",()->{
            try{startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));}
            catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}});
        tool("All apps","Browse installed applications",()->showDrawer("All Apps"));
        tool("Home screen","Return to Black Glass home",this::showHome);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==PICK_WALLPAPER&&result==RESULT_OK&&data!=null&&data.getData()!=null){
            try(InputStream in=getContentResolver().openInputStream(data.getData())){
                Bitmap bmp=BitmapFactory.decodeStream(in);if(bmp==null)throw new Exception("Invalid image");
                WallpaperManager.getInstance(this).setBitmap(bmp);Toast.makeText(this,"Wallpaper saved",Toast.LENGTH_SHORT).show();
            }catch(Exception ex){Toast.makeText(this,"Wallpaper could not be set",Toast.LENGTH_LONG).show();}
        }
    }
    @Override public void onBackPressed(){if(drawer)showHome();else super.onBackPressed();}
}
