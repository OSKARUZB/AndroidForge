# BLACK GLASS launcher — English only

Android Studio project using the user's **36 original Glass 3D icon images**. Nothing in this ZIP is a prebuilt APK.

## Build an APK
1. Open `BlackGlassLauncher` as a project in Android Studio (JDK 17, Android SDK 35).
2. Wait for Gradle sync. An internet connection may be required for Gradle/Android plugin downloads.
3. Choose **Build > Build APK(s)**.
4. APK location: `app/build/outputs/apk/debug/app-debug.apk`.
5. Install the APK on Android, tap **Tools > Set as default launcher**, and choose **Black Glass**.

## Features
- Dark launcher, no on-screen navigation buttons added by the app.
- Swipe up on empty Home area: all apps; swipe down: Tools.
- Draggable clock on the Home screen. Position is remembered.
- Automatic Games, Google, Social, Apps groupings (best effort based on package and Android app category).
- Supplied 36 glass icon assets mapped onto recognized installed apps; unmatched apps keep their real Android icon.
- Wallpaper chooser; access to storage settings through `Clean cache` (Android does not allow regular third-party launchers to silently clear every app's cache).
- Open app by tapping; long press opens Android app settings.
- English-only labels, Android 8.0+ supported, Android 10 compatible.

## Notes
- The phone's own system gesture/navigation bar is managed by Android, not a launcher.
- The package detection for game folders is heuristic; not all game apps will automatically be recognized.
- To comply with Android package visibility, the app queries only launchable activities.
- Launcher needs to be selected in system **Default apps > Home app** before it can replace the stock Home screen.
- This project has not been compiled or device-tested in this environment because Android build tools/SDK are unavailable.
