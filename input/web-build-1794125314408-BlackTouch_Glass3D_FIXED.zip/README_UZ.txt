BLACKTOUCH — GLASS 3D ICONS FIXED

Paket tarkibi:
1) BlackTouch_Glass3D_FIXED.apk — siz yuborgan BlackTouch APK ichidagi 36 ta eski ikonka asl 256x256 PNG fayllarga almashtirildi.
2) Glass_3D_Icons_36.zip — asl 36 ta PNG ikonka.

O‘rnatish:
- APK qayta imzolangan. Agar eski BlackTouch ilovasi o‘rnatilgan bo‘lsa, avval uni o‘chirib, keyin yangisini o‘rnating. Bu eski ilova sozlamalarini o‘chirishi mumkin.
- APKni Android qurilmangizda oching va o‘rnating.

Eslatma:
- Bu tuzatish APK ichidagi rasmlarni to‘g‘ri almashtiradi. Telefonda boshqa barcha dasturlar avtomatik aynan shu ko‘rinishda chiqishini kafolatlamaydi: bu launcher kodidagi ilova→ikonka moslashiga ham bog‘liq.
- Qayta imzolash uchun yangi lokal kalit ishlatildi. Asl dasturchining raqamli imzosi saqlanmagan.
